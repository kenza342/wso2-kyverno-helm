<?xml version='1.0' encoding='UTF-8'?>
<?profile version='1.0.0'?>
<profile id='gateway-worker' timestamp='1776906259098'>
  <properties size='5'>
    <property name='org.eclipse.equinox.p2.cache' value='/home/jenkins/workspace/products/product_apim/product-apim/all-in-one-apim/modules/p2-profile/product/target/wso2carbon-core-4.11.18/repository/components'/>
    <property name='org.eclipse.update.install.features' value='true'/>
    <property name='org.eclipse.equinox.p2.roaming' value='false'/>
    <property name='org.eclipse.equinox.p2.environments' value='osgi.os=linux,osgi.arch=x86,osgi.ws=gtk,osgi.nl=en'/>
    <property name='org.eclipse.equinox.p2.installFolder' value='/home/jenkins/workspace/products/product_apim/product-apim/all-in-one-apim/modules/p2-profile/product/target/wso2carbon-core-4.11.18/repository/components/gateway-worker'/>
  </properties>
</profile>
