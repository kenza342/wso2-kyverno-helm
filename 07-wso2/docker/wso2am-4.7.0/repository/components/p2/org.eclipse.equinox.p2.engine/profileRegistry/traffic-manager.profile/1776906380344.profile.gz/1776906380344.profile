<?xml version='1.0' encoding='UTF-8'?>
<?profile version='1.0.0'?>
<profile id='traffic-manager' timestamp='1776906380344'>
  <properties size='5'>
    <property name='org.eclipse.equinox.p2.cache' value='/home/jenkins/workspace/products/product_apim/product-apim/all-in-one-apim/modules/p2-profile/product/target/wso2carbon-core-4.11.18/repository/components'/>
    <property name='org.eclipse.update.install.features' value='true'/>
    <property name='org.eclipse.equinox.p2.roaming' value='false'/>
    <property name='org.eclipse.equinox.p2.environments' value='osgi.os=linux,osgi.arch=x86,osgi.ws=gtk,osgi.nl=en'/>
    <property name='org.eclipse.equinox.p2.installFolder' value='/home/jenkins/workspace/products/product_apim/product-apim/all-in-one-apim/modules/p2-profile/product/target/wso2carbon-core-4.11.18/repository/components/traffic-manager'/>
  </properties>
  <units size='86'>
    <unit id='a.jre.javase' version='21.0.0' singleton='false'>
      <provides size='260'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='a.jre.javase' version='21.0.0'/>
        <provided namespace='java.package' name='com.sun.java.accessibility.util' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.jdi' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.jdi.connect' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.jdi.connect.spi' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.jdi.event' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.jdi.request' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.management' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.net.httpserver' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.net.httpserver.spi' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.nio.file' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.nio.sctp' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.security.auth' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.security.auth.callback' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.security.auth.login' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.security.auth.module' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.security.jgss' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.source.doctree' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.source.tree' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.source.util' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.tools.attach' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.tools.attach.spi' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.tools.javac' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.tools.jconsole' version='0.0.0'/>
        <provided namespace='java.package' name='java.applet' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.color' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.datatransfer' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.desktop' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.dnd' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.event' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.font' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.geom' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.im' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.im.spi' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.image' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.image.renderable' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.print' version='0.0.0'/>
        <provided namespace='java.package' name='java.beans' version='0.0.0'/>
        <provided namespace='java.package' name='java.beans.beancontext' version='0.0.0'/>
        <provided namespace='java.package' name='java.io' version='0.0.0'/>
        <provided namespace='java.package' name='java.lang' version='0.0.0'/>
        <provided namespace='java.package' name='java.lang.annotation' version='0.0.0'/>
        <provided namespace='java.package' name='java.lang.constant' version='0.0.0'/>
        <provided namespace='java.package' name='java.lang.foreign' version='0.0.0'/>
        <provided namespace='java.package' name='java.lang.instrument' version='0.0.0'/>
        <provided namespace='java.package' name='java.lang.invoke' version='0.0.0'/>
        <provided namespace='java.package' name='java.lang.management' version='0.0.0'/>
        <provided namespace='java.package' name='java.lang.module' version='0.0.0'/>
        <provided namespace='java.package' name='java.lang.ref' version='0.0.0'/>
        <provided namespace='java.package' name='java.lang.reflect' version='0.0.0'/>
        <provided namespace='java.package' name='java.lang.runtime' version='0.0.0'/>
        <provided namespace='java.package' name='java.math' version='0.0.0'/>
        <provided namespace='java.package' name='java.net' version='0.0.0'/>
        <provided namespace='java.package' name='java.net.http' version='0.0.0'/>
        <provided namespace='java.package' name='java.net.spi' version='0.0.0'/>
        <provided namespace='java.package' name='java.nio' version='0.0.0'/>
        <provided namespace='java.package' name='java.nio.channels' version='0.0.0'/>
        <provided namespace='java.package' name='java.nio.channels.spi' version='0.0.0'/>
        <provided namespace='java.package' name='java.nio.charset' version='0.0.0'/>
        <provided namespace='java.package' name='java.nio.charset.spi' version='0.0.0'/>
        <provided namespace='java.package' name='java.nio.file' version='0.0.0'/>
        <provided namespace='java.package' name='java.nio.file.attribute' version='0.0.0'/>
        <provided namespace='java.package' name='java.nio.file.spi' version='0.0.0'/>
        <provided namespace='java.package' name='java.rmi' version='0.0.0'/>
        <provided namespace='java.package' name='java.rmi.dgc' version='0.0.0'/>
        <provided namespace='java.package' name='java.rmi.registry' version='0.0.0'/>
        <provided namespace='java.package' name='java.rmi.server' version='0.0.0'/>
        <provided namespace='java.package' name='java.security' version='0.0.0'/>
        <provided namespace='java.package' name='java.security.cert' version='0.0.0'/>
        <provided namespace='java.package' name='java.security.interfaces' version='0.0.0'/>
        <provided namespace='java.package' name='java.security.spec' version='0.0.0'/>
        <provided namespace='java.package' name='java.sql' version='0.0.0'/>
        <provided namespace='java.package' name='java.text' version='0.0.0'/>
        <provided namespace='java.package' name='java.text.spi' version='0.0.0'/>
        <provided namespace='java.package' name='java.time' version='0.0.0'/>
        <provided namespace='java.package' name='java.time.chrono' version='0.0.0'/>
        <provided namespace='java.package' name='java.time.format' version='0.0.0'/>
        <provided namespace='java.package' name='java.time.temporal' version='0.0.0'/>
        <provided namespace='java.package' name='java.time.zone' version='0.0.0'/>
        <provided namespace='java.package' name='java.util' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.concurrent' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.concurrent.atomic' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.concurrent.locks' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.function' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.jar' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.logging' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.prefs' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.random' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.regex' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.spi' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.stream' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.zip' version='0.0.0'/>
        <provided namespace='java.package' name='javax.accessibility' version='0.0.0'/>
        <provided namespace='java.package' name='javax.annotation.processing' version='0.0.0'/>
        <provided namespace='java.package' name='javax.crypto' version='0.0.0'/>
        <provided namespace='java.package' name='javax.crypto.interfaces' version='0.0.0'/>
        <provided namespace='java.package' name='javax.crypto.spec' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio.event' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio.metadata' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio.plugins.bmp' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio.plugins.jpeg' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio.plugins.tiff' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio.stream' version='0.0.0'/>
        <provided namespace='java.package' name='javax.lang.model' version='0.0.0'/>
        <provided namespace='java.package' name='javax.lang.model.element' version='0.0.0'/>
        <provided namespace='java.package' name='javax.lang.model.type' version='0.0.0'/>
        <provided namespace='java.package' name='javax.lang.model.util' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.loading' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.modelmbean' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.monitor' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.openmbean' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.relation' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.remote' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.remote.rmi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.timer' version='0.0.0'/>
        <provided namespace='java.package' name='javax.naming' version='0.0.0'/>
        <provided namespace='java.package' name='javax.naming.directory' version='0.0.0'/>
        <provided namespace='java.package' name='javax.naming.event' version='0.0.0'/>
        <provided namespace='java.package' name='javax.naming.ldap' version='0.0.0'/>
        <provided namespace='java.package' name='javax.naming.ldap.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.naming.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.net' version='0.0.0'/>
        <provided namespace='java.package' name='javax.net.ssl' version='0.0.0'/>
        <provided namespace='java.package' name='javax.print' version='0.0.0'/>
        <provided namespace='java.package' name='javax.print.attribute' version='0.0.0'/>
        <provided namespace='java.package' name='javax.print.attribute.standard' version='0.0.0'/>
        <provided namespace='java.package' name='javax.print.event' version='0.0.0'/>
        <provided namespace='java.package' name='javax.rmi.ssl' version='0.0.0'/>
        <provided namespace='java.package' name='javax.script' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.auth' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.auth.callback' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.auth.kerberos' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.auth.login' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.auth.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.auth.x500' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.cert' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.sasl' version='0.0.0'/>
        <provided namespace='java.package' name='javax.smartcardio' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sound.midi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sound.midi.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sound.sampled' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sound.sampled.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sql' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sql.rowset' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sql.rowset.serial' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sql.rowset.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.border' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.colorchooser' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.event' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.filechooser' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.plaf' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.plaf.basic' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.plaf.metal' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.plaf.multi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.plaf.nimbus' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.plaf.synth' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.table' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.text' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.text.html' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.text.html.parser' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.text.rtf' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.tree' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.undo' version='0.0.0'/>
        <provided namespace='java.package' name='javax.tools' version='0.0.0'/>
        <provided namespace='java.package' name='javax.transaction.xa' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.catalog' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.crypto' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.crypto.dom' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.crypto.dsig' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.crypto.dsig.dom' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.crypto.dsig.keyinfo' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.crypto.dsig.spec' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.datatype' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.namespace' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.parsers' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.stream' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.stream.events' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.stream.util' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.transform' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.transform.dom' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.transform.sax' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.transform.stax' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.transform.stream' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.validation' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.xpath' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.dynalink' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.dynalink.beans' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.dynalink.linker' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.dynalink.linker.support' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.dynalink.support' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.javadoc.doclet' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.jfr' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.jfr.consumer' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.jshell' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.jshell.execution' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.jshell.spi' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.jshell.tool' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.management.jfr' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.net' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.nio' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.nio.mapmode' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.security.jarsigner' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.swing.interop' version='0.0.0'/>
        <provided namespace='java.package' name='netscape.javascript' version='0.0.0'/>
        <provided namespace='java.package' name='org.ietf.jgss' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.bootstrap' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.css' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.events' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.html' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.ls' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.ranges' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.stylesheets' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.traversal' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.views' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.xpath' version='0.0.0'/>
        <provided namespace='java.package' name='org.xml.sax' version='0.0.0'/>
        <provided namespace='java.package' name='org.xml.sax.ext' version='0.0.0'/>
        <provided namespace='java.package' name='org.xml.sax.helpers' version='0.0.0'/>
        <provided namespace='java.package' name='sun.misc' version='0.0.0'/>
        <provided namespace='java.package' name='sun.reflect' version='0.0.0'/>
        <provided namespace='osgi.ee' name='OSGi/Minimum' version='1.0.0'/>
        <provided namespace='osgi.ee' name='OSGi/Minimum' version='1.1.0'/>
        <provided namespace='osgi.ee' name='OSGi/Minimum' version='1.2.0'/>
        <provided namespace='osgi.ee' name='JRE' version='1.0.0'/>
        <provided namespace='osgi.ee' name='JRE' version='1.1.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='1.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='1.1.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='1.2.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='1.3.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='1.4.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='1.5.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='1.6.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='1.7.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='1.8.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='9.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='10.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='11.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='12.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='13.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='14.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='15.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='16.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='17.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='18.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='19.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='20.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='21.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE/compact1' version='1.8.0'/>
        <provided namespace='osgi.ee' name='JavaSE/compact1' version='21.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE/compact2' version='1.8.0'/>
        <provided namespace='osgi.ee' name='JavaSE/compact2' version='21.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE/compact3' version='1.8.0'/>
        <provided namespace='osgi.ee' name='JavaSE/compact3' version='21.0.0'/>
      </provides>
      <touchpoint id='org.eclipse.equinox.p2.native' version='1.0.0'/>
    </unit>
    <unit id='bcpg-jdk18on' version='1.84.0.wso2v1' singleton='false' generation='2'>
      <update id='bcpg-jdk18on' range='[0.0.0,1.84.0.wso2v1)' severity='0'/>
      <properties size='2'>
        <property name='org.eclipse.equinox.p2.name' value='bcpg-jdk18on'/>
        <property name='org.eclipse.equinox.p2.description' value='This bundle will represent bouncycastle 1.84'/>
      </properties>
      <provides size='24'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='bcpg-jdk18on' version='1.84.0.wso2v1'/>
        <provided namespace='osgi.bundle' name='bcpg-jdk18on' version='1.84.0.wso2v1'/>
        <provided namespace='java.package' name='org.bouncycastle.apache.bzip2' version='1.84.0'/>
        <provided namespace='java.package' name='org.bouncycastle.bcpg' version='1.84.0'/>
        <provided namespace='java.package' name='org.bouncycastle.bcpg.attr' version='1.84.0'/>
        <provided namespace='java.package' name='org.bouncycastle.bcpg.sig' version='1.84.0'/>
        <provided namespace='java.package' name='org.bouncycastle.gpg' version='1.84.0'/>
        <provided namespace='java.package' name='org.bouncycastle.gpg.keybox' version='1.84.0'/>
        <provided namespace='java.package' name='org.bouncycastle.gpg.keybox.bc' version='1.84.0'/>
        <provided namespace='java.package' name='org.bouncycastle.gpg.keybox.jcajce' version='1.84.0'/>
        <provided namespace='java.package' name='org.bouncycastle.openpgp' version='1.84.0'/>
        <provided namespace='java.package' name='org.bouncycastle.openpgp.api' version='1.84.0'/>
        <provided namespace='java.package' name='org.bouncycastle.openpgp.api.bc' version='1.84.0'/>
        <provided namespace='java.package' name='org.bouncycastle.openpgp.api.exception' version='1.84.0'/>
        <provided namespace='java.package' name='org.bouncycastle.openpgp.api.jcajce' version='1.84.0'/>
        <provided namespace='java.package' name='org.bouncycastle.openpgp.api.util' version='1.84.0'/>
        <provided namespace='java.package' name='org.bouncycastle.openpgp.bc' version='1.84.0'/>
        <provided namespace='java.package' name='org.bouncycastle.openpgp.examples' version='1.84.0'/>
        <provided namespace='java.package' name='org.bouncycastle.openpgp.jcajce' version='1.84.0'/>
        <provided namespace='java.package' name='org.bouncycastle.openpgp.operator' version='1.84.0'/>
        <provided namespace='java.package' name='org.bouncycastle.openpgp.operator.bc' version='1.84.0'/>
        <provided namespace='java.package' name='org.bouncycastle.openpgp.operator.jcajce' version='1.84.0'/>
        <provided namespace='osgi.identity' name='bcpg-jdk18on' version='1.84.0.wso2v1'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            bcpg-jdk18on
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='bcpg-jdk18on' version='1.84.0.wso2v1'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: bcpg-jdk18on&#xA;Bundle-Version: 1.84.0.wso2v1
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='carbon.product.id' version='4.11.18'>
      <update id='carbon.product.id' range='0.0.0' severity='0'/>
      <properties size='3'>
        <property name='org.eclipse.equinox.p2.name' value='Carbon Product'/>
        <property name='org.eclipse.equinox.p2.type.product' value='true'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='carbon.product.id' version='4.11.18'/>
      </provides>
      <requires size='6'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.wso2.carbon.core.runtime.feature.group' range='[4.11.18,4.11.18]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingcarbon.product.id.configuration' range='[4.11.18,4.11.18]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='tooling.org.eclipse.update.feature.default' range='[1.0.0,1.0.0]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='tooling.source.default' range='[1.0.0,1.0.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='tooling.osgi.bundle.default' range='[1.0.0,1.0.0]'/>
        <required namespace='osgi.ee' name='JavaSE' range='0.0.0'/>
      </requires>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
    </unit>
    <unit id='commons-httpclient' version='3.1.0.wso2v7' singleton='false'>
      <update id='commons-httpclient' range='[0.0.0,3.1.0.wso2v7)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='commons-httpclient'/>
        <property name='org.eclipse.equinox.p2.description' value='This bundle will export packages from commons-httpclient.jar'/>
        <property name='org.eclipse.equinox.p2.provider' value='WSO2'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='http://www.wso2.org/'/>
      </properties>
      <provides size='18'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='commons-httpclient' version='3.1.0.wso2v7'/>
        <provided namespace='osgi.bundle' name='commons-httpclient' version='3.1.0.wso2v7'/>
        <provided namespace='java.package' name='org.apache.commons.ssl.asn1' version='3.1.0'/>
        <provided namespace='java.package' name='org.apache.commons.ssl' version='3.1.0'/>
        <provided namespace='java.package' name='org.apache.commons.ssl.rmi' version='3.1.0'/>
        <provided namespace='java.package' name='org.apache.commons.ssl.util' version='3.1.0'/>
        <provided namespace='java.package' name='org.apache.commons.httpclient.protocol' version='3.1.0'/>
        <provided namespace='java.package' name='org.apache.commons.httpclient.auth' version='3.1.0'/>
        <provided namespace='java.package' name='org.apache.commons.httpclient.contrib.ssl' version='3.1.0'/>
        <provided namespace='java.package' name='org.apache.commons.httpclient.cookie' version='3.1.0'/>
        <provided namespace='java.package' name='org.apache.commons.httpclient.methods.multipart' version='3.1.0'/>
        <provided namespace='java.package' name='org.apache.commons.httpclient' version='3.1.0'/>
        <provided namespace='java.package' name='org.apache.commons.httpclient.conn.util' version='3.1.0'/>
        <provided namespace='java.package' name='org.apache.commons.httpclient.methods' version='3.1.0'/>
        <provided namespace='java.package' name='org.apache.commons.httpclient.params' version='3.1.0'/>
        <provided namespace='java.package' name='org.apache.commons.httpclient.util' version='3.1.0'/>
        <provided namespace='osgi.identity' name='commons-httpclient' version='3.1.0.wso2v7'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='19'>
        <required namespace='java.package' name='com.sun.crypto.provider' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='com.sun.net.ssl' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='com.sun.net.ssl.internal.ssl' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.crypto' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.crypto.spec' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.naming' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.naming.directory' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.naming.ldap' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.net' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.net.ssl' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.security.auth.x500' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.security.cert' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.commons.codec' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.commons.codec.binary' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.commons.codec.net' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.commons.logging' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.log4j' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.w3c.dom' range='0.0.0' optional='true' greedy='false'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='commons-httpclient' version='3.1.0.wso2v7'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: commons-httpclient&#xA;Bundle-Version: 3.1.0.wso2v7
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.apache.felix.gogo.command' version='1.1.2' singleton='false' generation='2'>
      <update id='org.apache.felix.gogo.command' range='[0.0.0,1.1.2)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='Apache Felix Gogo Command'/>
        <property name='org.eclipse.equinox.p2.description' value='Provides basic shell commands for Gogo.'/>
        <property name='org.eclipse.equinox.p2.provider' value='The Apache Software Foundation'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://www.apache.org/'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.apache.felix.gogo.command' version='1.1.2'/>
        <provided namespace='osgi.bundle' name='org.apache.felix.gogo.command' version='1.1.2'/>
        <provided namespace='java.package' name='org.apache.felix.gogo.command' version='1.1.2'/>
        <provided namespace='osgi.identity' name='org.apache.felix.gogo.command' version='1.1.2'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.apache.felix.gogo' name='command.implementation' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='6'>
        <required namespace='java.package' name='org.apache.felix.service.command' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.8.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework.startlevel' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework.wiring' range='[1.2.0,2.0.0)'/>
        <requiredProperties namespace='org.apache.felix.gogo' match='(&amp;(org.apache.felix.gogo=runtime.implementation)(version&gt;=1.0.0)(!(version&gt;=2.0.0)))'>
          <description>
            org.apache.felix.gogo.command
          </description>
        </requiredProperties>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.7))'>
          <description>
            org.apache.felix.gogo.command
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.apache.felix.gogo.command' version='1.1.2'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.apache.felix.gogo.command&#xA;Bundle-Version: 1.1.2
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.apache.felix.gogo.runtime' version='1.1.6' singleton='false' generation='2'>
      <update id='org.apache.felix.gogo.runtime' range='[0.0.0,1.1.6)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='Apache Felix Gogo Runtime'/>
        <property name='org.eclipse.equinox.p2.description' value='Apache Felix Gogo Subproject'/>
        <property name='org.eclipse.equinox.p2.provider' value='The Apache Software Foundation'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://www.apache.org/'/>
      </properties>
      <provides size='13'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.apache.felix.gogo.runtime' version='1.1.6'/>
        <provided namespace='osgi.bundle' name='org.apache.felix.gogo.runtime' version='1.1.6'/>
        <provided namespace='java.package' name='org.apache.felix.gogo.runtime' version='1.1.6'/>
        <provided namespace='java.package' name='org.apache.felix.gogo.runtime.activator' version='1.1.6'/>
        <provided namespace='java.package' name='org.apache.felix.gogo.runtime.threadio' version='1.1.6'/>
        <provided namespace='java.package' name='org.apache.felix.service.command' version='1.0.0'/>
        <provided namespace='java.package' name='org.apache.felix.service.command.annotations' version='1.0.0'/>
        <provided namespace='java.package' name='org.apache.felix.service.threadio' version='1.0.0'/>
        <provided namespace='osgi.identity' name='org.apache.felix.gogo.runtime' version='1.1.6'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.apache.felix.gogo' name='runtime.implementation' version='1.0.0'/>
        <provided namespace='osgi.service' name='org.apache.felix.gogo.runtime_1.1.6-2' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.apache.felix.service.command.CommandProcessor'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.apache.felix.gogo.runtime_1.1.6-3' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.apache.felix.service.threadio.ThreadIO'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='8'>
        <required namespace='java.package' name='org.osgi.service.event' range='[1.3.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.felix.gogo.runtime.threadio' range='[1.1.0,2.0.0)'/>
        <required namespace='java.package' name='org.apache.felix.service.command' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.apache.felix.service.threadio' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.8.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='[1.5.0,2.0.0)'/>
        <requiredProperties namespace='org.apache.felix.gogo' match='(&amp;(org.apache.felix.gogo=shell.implementation)(version&gt;=1.0.0)(!(version&gt;=2.0.0)))'>
          <description>
            org.apache.felix.gogo.runtime
          </description>
        </requiredProperties>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.7))'>
          <description>
            org.apache.felix.gogo.runtime
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.apache.felix.gogo.runtime' version='1.1.6'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.apache.felix.gogo.runtime&#xA;Bundle-Version: 1.1.6
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.apache.felix.gogo.shell' version='1.1.4' singleton='false' generation='2'>
      <update id='org.apache.felix.gogo.shell' range='[0.0.0,1.1.4)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='Apache Felix Gogo Shell'/>
        <property name='org.eclipse.equinox.p2.description' value='Apache Felix Gogo Subproject'/>
        <property name='org.eclipse.equinox.p2.provider' value='The Apache Software Foundation'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://www.apache.org/'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.apache.felix.gogo.shell' version='1.1.4'/>
        <provided namespace='osgi.bundle' name='org.apache.felix.gogo.shell' version='1.1.4'/>
        <provided namespace='osgi.identity' name='org.apache.felix.gogo.shell' version='1.1.4'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.apache.felix.gogo' name='shell.implementation' version='1.0.0'>
          <properties size='1'>
            <property name='implementation.name' value='gogo.shell'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='6'>
        <required namespace='java.package' name='org.apache.felix.service.command' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.8.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework.startlevel' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='[1.5.0,2.0.0)'/>
        <requiredProperties namespace='org.apache.felix.gogo' match='(&amp;(org.apache.felix.gogo=command.implementation)(version&gt;=1.0.0)(!(version&gt;=2.0.0)))'>
          <description>
            org.apache.felix.gogo.shell
          </description>
        </requiredProperties>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.7))'>
          <description>
            org.apache.felix.gogo.shell
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.apache.felix.gogo.shell' version='1.1.4'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.apache.felix.gogo.shell&#xA;Bundle-Version: 1.1.4
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.apache.felix.scr' version='2.2.10' singleton='false' generation='2'>
      <update id='org.apache.felix.scr' range='[0.0.0,2.2.10)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='Apache Felix Declarative Services'/>
        <property name='org.eclipse.equinox.p2.description' value='Implementation of the Declarative Services specification 1.5'/>
        <property name='org.eclipse.equinox.p2.provider' value='The Apache Software Foundation'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='http://felix.apache.org/site/apache-felix-service-component-runtime.html'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.apache.felix.scr' version='2.2.10'/>
        <provided namespace='osgi.bundle' name='org.apache.felix.scr' version='2.2.10'/>
        <provided namespace='java.package' name='org.apache.felix.scr.component' version='1.1.0'/>
        <provided namespace='java.package' name='org.apache.felix.scr.info' version='1.0.0'/>
        <provided namespace='osgi.identity' name='org.apache.felix.scr' version='2.2.10'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='osgi.extender' name='osgi.component' version='1.5.0'/>
        <provided namespace='osgi.service' name='org.apache.felix.scr_2.2.10-2' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.osgi.service.component.runtime.ServiceComponentRuntime' type='List'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='21'>
        <required namespace='java.package' name='org.osgi.service.cm' range='[1.6.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.service.log' range='[1.4.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.service.metatype' range='[1.2.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.felix.service.command' range='[1.0.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.apache.felix.scr.component' range='[1.1.0,1.2.0)'/>
        <required namespace='java.package' name='org.apache.felix.scr.info' range='[1.0.0,1.1.0)'/>
        <required namespace='java.package' name='org.osgi.dto' range='[1.1.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.10.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework.dto' range='[1.8.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework.startlevel' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework.wiring' range='[1.2.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.resource' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.service.component' range='[1.5.0,1.6.0)'/>
        <required namespace='java.package' name='org.osgi.service.component.runtime' range='[1.5.0,1.6.0)'/>
        <required namespace='java.package' name='org.osgi.service.component.runtime.dto' range='[1.5.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.util.promise' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='[1.5.0,2.0.0)'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax.helpers' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(|(&amp;(osgi.ee=JavaSE)(version=1.7))(&amp;(osgi.ee=JavaSE/compact1)(version=1.8)))'>
          <description>
            org.apache.felix.scr
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.apache.felix.scr' version='2.2.10'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.apache.felix.scr&#xA;Bundle-Version: 2.2.10
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.contenttype' version='3.9.300.v20231218-0909' generation='2'>
      <update id='org.eclipse.core.contenttype' range='[0.0.0,3.9.300.v20231218-0909)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.pluginName' value='Eclipse Content Mechanism'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.contenttype' version='3.9.300.v20231218-0909'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.contenttype' version='3.9.300.v20231218-0909'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.content' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime.content' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.core.contenttype' version='3.9.300.v20231218-0909'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='12'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.preferences' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.13.0,4.0.0)'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax.ext' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax.helpers' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.core.contenttype
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.contenttype' version='3.9.300.v20231218-0909'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.contenttype; singleton:=true&#xA;Bundle-Version: 3.9.300.v20231218-0909
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.expressions' version='3.9.300.v20240207-1044' generation='2'>
      <update id='org.eclipse.core.expressions' range='[0.0.0,3.9.300.v20240207-1044)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.pluginName' value='Expression Language'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='9'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.expressions' version='3.9.300.v20240207-1044'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.expressions' version='3.9.300.v20240207-1044'/>
        <provided namespace='java.package' name='org.eclipse.core.expressions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.expressions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.expressions.propertytester' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.expressions.util' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.core.expressions' version='3.9.300.v20240207-1044'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.29.0,4.0.0)'/>
        <required namespace='java.package' name='org.w3c.dom' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.core.expressions
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.expressions' version='3.9.300.v20240207-1044'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.expressions; singleton:=true&#xA;Bundle-Version: 3.9.300.v20240207-1044
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.jobs' version='3.15.200.v20231214-1526' generation='2'>
      <update id='org.eclipse.core.jobs' range='[0.0.0,3.15.200.v20231214-1526)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.pluginName' value='Eclipse Jobs Mechanism'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.jobs' version='3.15.200.v20231214-1526'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.jobs' version='3.15.200.v20231214-1526'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.jobs' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.jobs' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime.jobs' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.core.jobs' version='3.15.200.v20231214-1526'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='7'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.8.0,4.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.core.jobs
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.jobs' version='3.15.200.v20231214-1526'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.jobs; singleton:=true&#xA;Bundle-Version: 3.15.200.v20231214-1526
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.runtime' version='3.31.0.v20240215-1631' generation='2'>
      <update id='org.eclipse.core.runtime' range='[0.0.0,3.31.0.v20240215-1631)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.pluginName' value='Core Runtime'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.runtime' version='3.31.0.v20240215-1631'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.runtime' version='3.31.0.v20240215-1631'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.preferences.legacy' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.runtime' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime' version='3.7.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.core.runtime' version='3.31.0.v20240215-1631'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='8'>
        <required namespace='osgi.bundle' name='org.eclipse.osgi' range='[3.18.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.19.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.jobs' range='[3.15.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='[3.12.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.preferences' range='[3.11.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.contenttype' range='[3.9.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.app' range='1.7.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.core.runtime
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.runtime' version='3.31.0.v20240215-1631'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.runtime; singleton:=true&#xA;Bundle-Version: 3.31.0.v20240215-1631
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.ecf' version='3.11.0.v20230507-1923' generation='2'>
      <update id='org.eclipse.ecf' range='[0.0.0,3.11.0.v20230507-1923)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.plugin.provider' value='Eclipse.org - ECF'/>
        <property name='df_LT.plugin.name' value='ECF Core API'/>
        <property name='org.eclipse.equinox.p2.name' value='%plugin.name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%plugin.provider'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='17'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf' version='3.11.0.v20230507-1923'/>
        <provided namespace='osgi.bundle' name='org.eclipse.ecf' version='3.11.0.v20230507-1923'/>
        <provided namespace='java.package' name='org.eclipse.ecf.core' version='3.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.core.events' version='3.1.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.core.jobs' version='1.1.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.core.provider' version='3.3.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.core.security' version='3.1.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.core.start' version='3.1.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.core.status' version='1.1.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.core.user' version='3.1.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.core.util' version='3.6.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.core.util.reflection' version='2.3.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.internal.core' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.ecf' version='3.11.0.v20230507-1923'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='ecf.containertype' name='org.eclipse.ecf_3.11.0.v20230507-1923-1' version='3.3.0'>
          <properties size='1'>
            <property name='names' value='ecf.base' type='List'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='9'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.0.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='[3.0.0,4.0.0)' optional='true' greedy='false'/>
        <required namespace='osgi.bundle' name='org.eclipse.ecf.identity' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.jobs' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.concurrent.future' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.3.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.service.log' range='[1.3.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='[1.3.2,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.ecf
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.ecf' version='3.11.0.v20230507-1923'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.ecf;singleton:=true&#xA;Bundle-Version: 3.11.0.v20230507-1923
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.ecf.filetransfer' version='5.1.103.v20230705-0614' generation='2'>
      <update id='org.eclipse.ecf.filetransfer' range='[0.0.0,5.1.103.v20230705-0614)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.plugin.provider' value='Eclipse.org - ECF'/>
        <property name='df_LT.plugin.name' value='ECF Filetransfer API'/>
        <property name='org.eclipse.equinox.p2.name' value='%plugin.name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%plugin.provider'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='12'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.filetransfer' version='5.1.103.v20230705-0614'/>
        <provided namespace='osgi.bundle' name='org.eclipse.ecf.filetransfer' version='5.1.103.v20230705-0614'/>
        <provided namespace='java.package' name='org.eclipse.ecf.filetransfer' version='5.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.filetransfer.events' version='5.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.filetransfer.events.socket' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.filetransfer.events.socketfactory' version='5.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.filetransfer.identity' version='5.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.filetransfer.service' version='5.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.internal.filetransfer' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.ecf.filetransfer' version='5.1.103.v20230705-0614'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='9'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.0.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='[3.0.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ecf' range='[3.0.0,4.0.0)'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.jobs' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.3.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.service.log' range='[1.3.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.service.url' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='[1.3.2,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.eclipse.ecf.filetransfer
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.ecf.filetransfer' version='5.1.103.v20230705-0614'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.ecf.filetransfer;singleton:=true&#xA;Bundle-Version: 5.1.103.v20230705-0614
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.ecf.identity' version='3.10.0.v20230422-0242' generation='2'>
      <update id='org.eclipse.ecf.identity' range='[0.0.0,3.10.0.v20230422-0242)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.plugin.provider' value='Eclipse.org - ECF'/>
        <property name='df_LT.plugin.name' value='ECF Identity Core API'/>
        <property name='org.eclipse.equinox.p2.name' value='%plugin.name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%plugin.provider'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='12'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.identity' version='3.10.0.v20230422-0242'/>
        <provided namespace='osgi.bundle' name='org.eclipse.ecf.identity' version='3.10.0.v20230422-0242'/>
        <provided namespace='java.package' name='org.eclipse.ecf.core.identity' version='3.3.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.core.util' version='3.6.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.internal.core.identity' version='3.2.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.ecf.identity' version='3.10.0.v20230422-0242'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='ecf.namespace' name='org.eclipse.ecf.identity_3.10.0.v20230422-0242-1' version='0.0.0'>
          <properties size='1'>
            <property name='names' value='”org.eclipse.ecf.core.identity.StringID' type='List'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.ecf.core.identity.GUID' name='org.eclipse.ecf.identity_3.10.0.v20230422-0242-2' version='0.0.0'/>
        <provided namespace='org.eclipse.ecf.core.identity.LongID' name='org.eclipse.ecf.identity_3.10.0.v20230422-0242-3' version='0.0.0'/>
        <provided namespace='org.eclipse.ecf.core.identity.URIID”' name='org.eclipse.ecf.identity_3.10.0.v20230422-0242-4' version='3.3.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='7'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.0.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='[3.0.0,4.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.3.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.service.log' range='[1.3.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='[1.3.2,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.ecf.identity
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.ecf.identity' version='3.10.0.v20230422-0242'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.ecf.identity;singleton:=true&#xA;Bundle-Version: 3.10.0.v20230422-0242
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.ecf.provider.filetransfer' version='3.3.0.v20230422-0242' generation='2'>
      <update id='org.eclipse.ecf.provider.filetransfer' range='[0.0.0,3.3.0.v20230422-0242)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.plugin.provider' value='Eclipse.org - ECF'/>
        <property name='df_LT.plugin.name' value='ECF Filetransfer Provider'/>
        <property name='org.eclipse.equinox.p2.name' value='%plugin.name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%plugin.provider'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='13'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.provider.filetransfer' version='3.3.0.v20230422-0242'/>
        <provided namespace='osgi.bundle' name='org.eclipse.ecf.provider.filetransfer' version='3.3.0.v20230422-0242'/>
        <provided namespace='java.package' name='org.eclipse.ecf.internal.provider.filetransfer' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.provider.filetransfer' version='3.2.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.provider.filetransfer.browse' version='3.2.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.provider.filetransfer.events.socket' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.provider.filetransfer.identity' version='3.2.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.provider.filetransfer.outgoing' version='3.2.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.provider.filetransfer.retrieve' version='3.2.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.provider.filetransfer.util' version='3.2.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.ecf.provider.filetransfer' version='3.3.0.v20230422-0242'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='13'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.0.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ecf' range='[3.0.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ecf.filetransfer' range='[5.0.0,6.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='[3.0.0,4.0.0)'/>
        <required namespace='java.package' name='org.eclipse.core.net.proxy' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.jobs' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.ecf.provider.filetransfer.events.socket' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.3.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.service.log' range='[1.3.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.service.url' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='[1.3.2,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.ecf.provider.filetransfer
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.ecf.provider.filetransfer' version='3.3.0.v20230422-0242'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.ecf.provider.filetransfer;singleton:=true&#xA;Bundle-Version: 3.3.0.v20230422-0242
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.ecf.provider.filetransfer.httpclient' version='4.0.200.v20120319-0616' generation='2'>
      <update id='org.eclipse.ecf.provider.filetransfer.httpclient' range='[0.0.0,4.0.200.v20120319-0616)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.plugin.provider' value='Eclipse.org - ECF'/>
        <property name='df_LT.plugin.name' value='ECF HttpClient Filetransfer Provider'/>
        <property name='org.eclipse.equinox.p2.name' value='%plugin.name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%plugin.provider'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.provider.filetransfer.httpclient' version='4.0.200.v20120319-0616'/>
        <provided namespace='osgi.bundle' name='org.eclipse.ecf.provider.filetransfer.httpclient' version='4.0.200.v20120319-0616'/>
        <provided namespace='java.package' name='org.eclipse.ecf.internal.provider.filetransfer.httpclient' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.provider.filetransfer.httpclient' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.ecf.provider.filetransfer.httpclient' version='4.0.200.v20120319-0616'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='17'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.ecf.provider.filetransfer' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.ecf' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.ecf.filetransfer' range='0.0.0'/>
        <required namespace='java.package' name='org.apache.commons.httpclient' range='[3.0.1,3.1.0]'/>
        <required namespace='java.package' name='org.apache.commons.httpclient.auth' range='[3.0.1,3.1.0]'/>
        <required namespace='java.package' name='org.apache.commons.httpclient.methods' range='[3.0.1,3.1.0]'/>
        <required namespace='java.package' name='org.apache.commons.httpclient.params' range='[3.0.1,3.1.0]'/>
        <required namespace='java.package' name='org.apache.commons.httpclient.protocol' range='[3.0.1,3.1.0]'/>
        <required namespace='java.package' name='org.apache.commons.httpclient.util' range='[3.0.1,3.1.0]'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.jobs' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.log' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.url' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.3.2'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.4))'>
          <description>
            org.eclipse.ecf.provider.filetransfer.httpclient
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.ecf.provider.filetransfer.httpclient' version='4.0.200.v20120319-0616'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.ecf.provider.filetransfer.httpclient;singleton:=true&#xA;Bundle-Version: 4.0.200.v20120319-0616
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.app' version='1.7.0.v20240213-1427' generation='2'>
      <update id='org.eclipse.equinox.app' range='[0.0.0,1.7.0.v20240213-1427)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.pluginName' value='Equinox Application Container'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.app' version='1.7.0.v20240213-1427'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.app' version='1.7.0.v20240213-1427'/>
        <provided namespace='java.package' name='org.eclipse.equinox.app' version='1.1.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.app' version='0.0.0'/>
        <provided namespace='java.package' name='org.osgi.service.application' version='1.1.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.app' version='1.7.0.v20240213-1427'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='16'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='[3.4.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.2.0,4.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.console' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.log' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.environment' range='1.1.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.runnable' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.storagemanager' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.condpermadmin' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.service.event' range='1.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='1.2.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.equinox.app
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.app' version='1.7.0.v20240213-1427'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.app; singleton:=true&#xA;Bundle-Version: 1.7.0.v20240213-1427
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.common' version='3.19.0.v20240214-0846' generation='2'>
      <update id='org.eclipse.equinox.common' range='[0.0.0,3.19.0.v20240214-0846)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.pluginName' value='Common Eclipse Runtime'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='10'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.common' version='3.19.0.v20240214-0846'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.common' version='3.19.0.v20240214-0846'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.boot' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.runtime' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime' version='3.7.0'/>
        <provided namespace='java.package' name='org.eclipse.core.text' version='3.13.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.events' version='1.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.common' version='3.19.0.v20240214-0846'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.osgi' range='[3.17.200,4.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.equinox.common
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.common' version='3.19.0.v20240214-0846'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.common; singleton:=true&#xA;Bundle-Version: 3.19.0.v20240214-0846
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.concurrent' version='1.3.0.v20240213-1244' singleton='false' generation='2'>
      <update id='org.eclipse.equinox.concurrent' range='[0.0.0,1.3.0.v20240213-1244)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.pluginName' value='Equinox Concurrent API'/>
        <property name='df_LT.pluginProvider' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%pluginProvider'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.concurrent' version='1.3.0.v20240213-1244'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.concurrent' version='1.3.0.v20240213-1244'/>
        <provided namespace='java.package' name='org.eclipse.equinox.concurrent.future' version='1.1.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.concurrent' version='1.3.0.v20240213-1244'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='4'>
        <required namespace='java.package' name='org.eclipse.core.runtime' range='3.4.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.equinox.concurrent
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.concurrent' version='1.3.0.v20240213-1244'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.concurrent&#xA;Bundle-Version: 1.3.0.v20240213-1244
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.console' version='1.4.700.v20240213-1244' singleton='false' generation='2'>
      <update id='org.eclipse.equinox.console' range='[0.0.0,1.4.700.v20240213-1244)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.bundleVendor' value='Eclipse.org - Equinox'/>
        <property name='df_LT.bundleName' value='Console plug-in'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%bundleVendor'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.console' version='1.4.700.v20240213-1244'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.console' version='1.4.700.v20240213-1244'/>
        <provided namespace='java.package' name='org.eclipse.equinox.console.common' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.console.common.terminal' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.console.completion.common' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.console' version='1.4.700.v20240213-1244'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='21'>
        <required namespace='java.package' name='org.apache.felix.service.command' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.container' range='[1.7.0,2.0.0]'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.console' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.report.resolution' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.environment' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework.hooks.resolver' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework.namespace' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.framework.startlevel' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework.wiring' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.resource' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.service.cm' range='[1.4.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.service.condpermadmin' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.service.permissionadmin' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.service.startlevel' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='0.0.0'/>
        <requiredProperties namespace='org.apache.felix.gogo' match='(org.apache.felix.gogo=runtime.implementation)'>
          <description>
            org.eclipse.equinox.console
          </description>
        </requiredProperties>
        <requiredProperties namespace='org.apache.felix.gogo' match='(org.apache.felix.gogo=shell.implementation)'>
          <description>
            org.eclipse.equinox.console
          </description>
        </requiredProperties>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.eclipse.equinox.console
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.console' version='1.4.700.v20240213-1244'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.console&#xA;Bundle-Version: 1.4.700.v20240213-1244
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.ds' version='1.6.200.v20200422-1833' generation='2'>
      <update id='org.eclipse.equinox.ds' range='[0.0.0,1.6.200.v20200422-1833)' severity='0'/>
      <properties size='6'>
        <property name='df_LT.bundleVendor' value='Eclipse.org - Equinox'/>
        <property name='df_LT.bundleName' value='Declarative Services'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.description' value='This bundle provides support for OSGi Declarative Services'/>
        <property name='org.eclipse.equinox.p2.provider' value='%bundleVendor'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.ds' version='1.6.200.v20200422-1833'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.ds' version='1.6.200.v20200422-1833'/>
        <provided namespace='java.package' name='org.apache.felix.scr' version='1.6.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.ds' version='1.6.200.v20200422-1833'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='13'>
        <required namespace='osgi.bundle' name='org.apache.felix.scr' range='[2.1.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.environment' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.8.0'/>
        <required namespace='java.package' name='org.osgi.framework.dto' range='1.8.0'/>
        <required namespace='java.package' name='org.osgi.framework.namespace' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.framework.startlevel' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.framework.wiring' range='1.2.0'/>
        <required namespace='java.package' name='org.osgi.service.component' range='1.4.0'/>
        <required namespace='java.package' name='org.osgi.service.component.runtime' range='1.4.0'/>
        <required namespace='java.package' name='org.osgi.service.component.runtime.dto' range='1.4.0'/>
        <required namespace='java.package' name='org.osgi.util.promise' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.5.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.6))'>
          <description>
            org.eclipse.equinox.ds
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.ds' version='1.6.200.v20200422-1833'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='3'>
          <instruction key='unconfigure'>
            setProgramProperty(propName:equinox.use.ds, propValue:);setProgramProperty(propName:ds.delayed.keepInstances, propValue:);
          </instruction>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.ds;singleton:=true&#xA;Bundle-Version: 1.6.200.v20200422-1833
          </instruction>
          <instruction key='configure'>
            setProgramProperty(propName:equinox.use.ds, propValue:true);setProgramProperty(propName:ds.delayed.keepInstances, propValue:true);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.frameworkadmin' version='2.3.100.v20240201-0843' generation='2'>
      <update id='org.eclipse.equinox.frameworkadmin' range='[0.0.0,2.3.100.v20240201-0843)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.pluginName' value='Equinox Framework Admin'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='9'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.frameworkadmin' version='2.3.100.v20240201-0843'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.frameworkadmin' version='2.3.100.v20240201-0843'/>
        <provided namespace='java.package' name='org.eclipse.equinox.frameworkadmin' version='2.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.frameworkadmin.utils' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.provisional.configuratormanipulator' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.provisional.frameworkadmin' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.frameworkadmin' version='2.3.100.v20240201-0843'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='5'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='3.4.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.pluginconversion' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.equinox.frameworkadmin
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.frameworkadmin' version='2.3.100.v20240201-0843'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.frameworkadmin;singleton:=true&#xA;Bundle-Version: 2.3.100.v20240201-0843
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.frameworkadmin.equinox' version='1.3.100.v20240213-1609' generation='2'>
      <update id='org.eclipse.equinox.frameworkadmin.equinox' range='[0.0.0,1.3.100.v20240213-1609)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.pluginName' value='Equinox Framework Admin for Equinox'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.frameworkadmin.equinox' version='1.3.100.v20240213-1609'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.frameworkadmin.equinox' version='1.3.100.v20240213-1609'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.frameworkadmin.equinox' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.frameworkadmin.equinox.utils' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.frameworkadmin.equinox' version='1.3.100.v20240213-1609'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='15'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='3.18.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.frameworkadmin' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.frameworkadmin.utils' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.configuratormanipulator' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.frameworkadmin' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='1.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.environment' range='1.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.resolver' range='1.1.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.framework.startlevel' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.service.log' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.startlevel' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.3.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.equinox.frameworkadmin.equinox
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.frameworkadmin.equinox' version='1.3.100.v20240213-1609'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.frameworkadmin.equinox;singleton:=true&#xA;Bundle-Version: 1.3.100.v20240213-1609
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.http.service.api' version='1.2.2.v20231218-2126' singleton='false' generation='2'>
      <update id='org.eclipse.equinox.http.service.api' range='[0.0.0,1.2.2.v20231218-2126)' severity='0'/>
      <properties size='3'>
        <property name='org.eclipse.equinox.p2.name' value='OSGi service http APIs'/>
        <property name='org.eclipse.equinox.p2.description' value='OSGi Companion Code for org.osgi.service.http Version 1.2.2'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse.org - Equinox'/>
      </properties>
      <provides size='9'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.http.service.api' version='1.2.2.v20231218-2126'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.http.service.api' version='1.2.2.v20231218-2126'/>
        <provided namespace='java.package' name='org.osgi.service.http' version='1.2.2'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.http.service.api' version='1.2.2.v20231218-2126'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='osgi.contract' name='JavaServlet' version='2.6.0'/>
        <provided namespace='osgi.contract' name='JavaServlet' version='3.0.0'/>
        <provided namespace='osgi.contract' name='JavaServlet' version='3.1.0'/>
        <provided namespace='osgi.contract' name='JavaServlet' version='4.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='java.package' name='javax.servlet' range='[2.1.0,5.0.0)'/>
        <required namespace='java.package' name='javax.servlet.http' range='[2.1.0,5.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.eclipse.equinox.http.service.api
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.http.service.api' version='1.2.2.v20231218-2126'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.http.service.api&#xA;Bundle-Version: 1.2.2.v20231218-2126
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.launcher' version='1.6.700.v20240213-1244' generation='2'>
      <update id='org.eclipse.equinox.launcher' range='[0.0.0,1.6.700.v20240213-1244)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.pluginName' value='Equinox Launcher'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='launcher'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher' version='1.6.700.v20240213-1244'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.launcher' version='1.6.700.v20240213-1244'/>
        <provided namespace='java.package' name='org.eclipse.core.launcher' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.launcher' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.launcher' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.launcher' version='1.6.700.v20240213-1244'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.eclipse.equinox.launcher
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.launcher' version='1.6.700.v20240213-1244'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.launcher;singleton:=true&#xA;Bundle-Version: 1.6.700.v20240213-1244
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.artifact.repository' version='1.4.0.v20210129-2007' generation='2'>
      <update id='org.eclipse.equinox.p2.artifact.repository' range='[0.0.0,1.4.0.v20210129-2007)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.pluginName' value='Equinox Provisioning Artifact Repository Support'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='12'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.artifact.repository' version='1.4.0.v20210129-2007'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.artifact.repository' version='1.4.0.v20210129-2007'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.artifact.processing' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.artifact.processors.checksum' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.artifact.processors.md5' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.artifact.processors.pack200' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.artifact.repository' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.artifact.repository.simple' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.artifact.repository.processing' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.p2.artifact.repository' version='1.4.0.v20210129-2007'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='29'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.7.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.p2.metadata' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.tukaani.xz' range='1.3.0'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.jobs' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.jarprocessor' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.persistence' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.repository.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.core.eventbus' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.internal.provisional.equinox.p2.jarprocessor' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='[1.3.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.signedcontent' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.prefs' range='1.1.1'/>
        <required namespace='java.package' name='org.w3c.dom' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0' optional='true' greedy='false'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'>
          <description>
            org.eclipse.equinox.p2.artifact.repository
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.artifact.repository' version='1.4.0.v20210129-2007'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.artifact.repository;singleton:=true&#xA;Bundle-Version: 1.4.0.v20210129-2007
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.console' version='1.2.0.v20210315-2042' generation='2'>
      <update id='org.eclipse.equinox.p2.console' range='[0.0.0,1.2.0.v20210315-2042)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.pluginName' value='Equinox Provisioning Console'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.console' version='1.2.0.v20210315-2042'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.console' version='1.2.0.v20210315-2042'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.console' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.p2.console' version='1.2.0.v20210315-2042'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='17'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='3.3.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.director' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.engine' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata' range='[2.4.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.planner' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.query' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.console' range='1.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.environment' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.6.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.4.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'>
          <description>
            org.eclipse.equinox.p2.console
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.console' version='1.2.0.v20210315-2042'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.console;singleton:=true&#xA;Bundle-Version: 1.2.0.v20210315-2042
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.core' version='2.8.0.v20210618-0742' generation='2'>
      <update id='org.eclipse.equinox.p2.core' range='[0.0.0,2.8.0.v20210618-0742)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.pluginName' value='Equinox Provisioning Core'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='10'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.core' version='2.8.0.v20210618-0742'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.core' version='2.8.0.v20210618-0742'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.core' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.core.eventbus' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.core' version='2.7.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.core.spi' version='2.1.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.p2.core' version='2.8.0.v20210618-0742'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='10'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.5.0,4.0.0)'/>
        <required namespace='java.package' name='org.bouncycastle.bcpg' range='1.65.0'/>
        <required namespace='java.package' name='org.bouncycastle.openpgp' range='1.65.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.eventmgr' range='1.2.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.log' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.6.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.5.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'>
          <description>
            org.eclipse.equinox.p2.core
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.core' version='2.8.0.v20210618-0742'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.core;singleton:=true&#xA;Bundle-Version: 2.8.0.v20210618-0742
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.director' version='2.5.0.v20210325-0750' generation='2'>
      <update id='org.eclipse.equinox.p2.director' range='[0.0.0,2.5.0.v20210325-0750)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.pluginName' value='Equinox Provisioning Director'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='9'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.director' version='2.5.0.v20210325-0750'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.director' version='2.5.0.v20210325-0750'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.director' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.rollback' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.director' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.planner' version='2.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.p2.director' version='2.5.0.v20210325-0750'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='14'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.3.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.jobs' range='[3.3.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.p2.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='osgi.bundle' name='org.sat4j.core' range='[2.3.5,3.0.0)'/>
        <required namespace='osgi.bundle' name='org.sat4j.pb' range='[2.3.5,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.configurator' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.engine' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.engine.query' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'>
          <description>
            org.eclipse.equinox.p2.director
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.director' version='2.5.0.v20210325-0750'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.director;singleton:=true&#xA;Bundle-Version: 2.5.0.v20210325-0750
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.director.app' version='1.2.0.v20210315-2042' generation='2'>
      <update id='org.eclipse.equinox.p2.director.app' range='[0.0.0,1.2.0.v20210315-2042)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.pluginName' value='Equinox Provisioning Director Application'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.director.app' version='1.2.0.v20210315-2042'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.director.app' version='1.2.0.v20210315-2042'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.director.app' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.p2.director.app' version='1.2.0.v20210315-2042'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='25'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.5.0,4.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.app' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.director' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.engine' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.core.eventbus' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.director' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core.spi' range='[2.1.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.engine' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.engine.query' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata.expression' range='2.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.planner' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.query' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.log' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.environment' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.6.0'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'>
          <description>
            org.eclipse.equinox.p2.director.app
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.director.app' version='1.2.0.v20210315-2042'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.director.app;singleton:=true&#xA;Bundle-Version: 1.2.0.v20210315-2042
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.directorywatcher' version='1.3.0.v20210316-1209' generation='2'>
      <update id='org.eclipse.equinox.p2.directorywatcher' range='[0.0.0,1.3.0.v20210316-1209)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.pluginName' value='Equinox Provisioning Directory Watcher'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.directorywatcher' version='1.3.0.v20210316-1209'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.directorywatcher' version='1.3.0.v20210316-1209'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.directorywatcher' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.p2.directorywatcher' version='1.3.0.v20210316-1209'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='20'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.7.0,4.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.artifact.repository.simple' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.expression' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.update' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.publisher' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.publisher.actions' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.publisher.eclipse' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.query' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.resolver' range='1.1.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.4.0'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='1.2.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'>
          <description>
            org.eclipse.equinox.p2.directorywatcher
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.directorywatcher' version='1.3.0.v20210316-1209'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.directorywatcher;singleton:=true&#xA;Bundle-Version: 1.3.0.v20210316-1209
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.engine' version='2.7.0.v20210328-0514' generation='2'>
      <update id='org.eclipse.equinox.p2.engine' range='[0.0.0,2.7.0.v20210328-0514)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.pluginName' value='Equinox Provisioning Engine'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='10'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.engine' version='2.7.0.v20210328-0514'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.engine' version='2.7.0.v20210328-0514'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.engine' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.engine.phases' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.engine' version='2.2.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.engine.query' version='2.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.engine.spi' version='2.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.p2.engine' version='2.7.0.v20210328-0514'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='35'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.jobs' range='[3.4.0,4.0.0)'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.internal.preferences' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.preferences' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.index' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.repository.io' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.persistence' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.core.eventbus' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata' range='[2.4.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata.expression' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata.index' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.query' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.spi' range='2.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='1.1.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.security' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.signedcontent' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.6.0'/>
        <required namespace='java.package' name='org.osgi.service.prefs' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.4.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'>
          <description>
            org.eclipse.equinox.p2.engine
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.engine' version='2.7.0.v20210328-0514'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.engine;singleton:=true&#xA;Bundle-Version: 2.7.0.v20210328-0514
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.extensionlocation' version='1.4.0.v20210316-1209' generation='2'>
      <update id='org.eclipse.equinox.p2.extensionlocation' range='[0.0.0,1.4.0.v20210316-1209)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.pluginName' value='Equinox Provisioning Extension Location Repository Support'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.extensionlocation' version='1.4.0.v20210316-1209'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.extensionlocation' version='1.4.0.v20210316-1209'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.extensionlocation' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.p2.extensionlocation' version='1.4.0.v20210316-1209'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='24'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.p2.metadata' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.artifact.repository.simple' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.publisher.eclipse' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.touchpoint.eclipse' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.update' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.directorywatcher' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.engine' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.publisher' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.publisher.eclipse' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='1.1.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.resolver' range='1.2.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.6.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'>
          <description>
            org.eclipse.equinox.p2.extensionlocation
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.extensionlocation' version='1.4.0.v20210316-1209'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.extensionlocation;singleton:=true&#xA;Bundle-Version: 1.4.0.v20210316-1209
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.garbagecollector' version='1.2.0.v20210316-1209' generation='2'>
      <update id='org.eclipse.equinox.p2.garbagecollector' range='[0.0.0,1.2.0.v20210316-1209)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.pluginName' value='Equinox Provisioning Garbage Collector'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.garbagecollector' version='1.2.0.v20210316-1209'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.garbagecollector' version='1.2.0.v20210316-1209'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.garbagecollector' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.p2.garbagecollector' version='1.2.0.v20210316-1209'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='17'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.p2.engine' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='[3.4.0,4.0.0)'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.preferences' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.app' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.core.eventbus' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.query' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='1.2.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.6.0'/>
        <required namespace='java.package' name='org.osgi.service.prefs' range='1.1.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'>
          <description>
            org.eclipse.equinox.p2.garbagecollector
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.garbagecollector' version='1.2.0.v20210316-1209'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.garbagecollector;singleton:=true&#xA;Bundle-Version: 1.2.0.v20210316-1209
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.jarprocessor' version='1.2.0.v20210507-0825' generation='2'>
      <update id='org.eclipse.equinox.p2.jarprocessor' range='[0.0.0,1.2.0.v20210507-0825)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.pluginName' value='Equinox Provisioning JAR Processor'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='9'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.jarprocessor' version='1.2.0.v20210507-0825'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.jarprocessor' version='1.2.0.v20210507-0825'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.jarprocessor' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.jarprocessor.unsigner' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.jarprocessor.verifier' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.internal.provisional.equinox.p2.jarprocessor' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.p2.jarprocessor' version='1.2.0.v20210507-0825'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='3.3.0'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.jobs' range='0.0.0' optional='true' greedy='false'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'>
          <description>
            org.eclipse.equinox.p2.jarprocessor
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.jarprocessor' version='1.2.0.v20210507-0825'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.jarprocessor;singleton:=true&#xA;Bundle-Version: 1.2.0.v20210507-0825
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.metadata' version='2.4.0.v20180320-1220' generation='2'>
      <update id='org.eclipse.equinox.p2.metadata' range='[0.0.0,2.4.0.v20180320-1220)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.pluginName' value='Equinox Provisioning Metadata'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='14'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.metadata' version='2.4.0.v20180320-1220'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.metadata' version='2.4.0.v20180320-1220'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.expression' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.expression.parser' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.index' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.query' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.metadata' version='2.4.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.metadata.expression' version='2.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.metadata.index' version='2.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.query' version='2.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.p2.metadata' version='2.4.0.v20180320-1220'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='6'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.localization' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.6.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.eclipse.equinox.p2.metadata
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.metadata' version='2.4.0.v20180320-1220'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.metadata;singleton:=true&#xA;Bundle-Version: 2.4.0.v20180320-1220
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.metadata.repository' version='1.4.0.v20210315-2228' generation='2'>
      <update id='org.eclipse.equinox.p2.metadata.repository' range='[0.0.0,1.4.0.v20210315-2228)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.pluginName' value='Equinox Provisioning Metadata Repository'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.metadata.repository' version='1.4.0.v20210315-2228'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.metadata.repository' version='1.4.0.v20210315-2228'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.repository' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.repository.io' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.metadata.io' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.p2.metadata.repository' version='1.4.0.v20210315-2228'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='27'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.tukaani.xz' range='1.3.0'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.index' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.persistence' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.repository.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.core.eventbus' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata' range='[2.4.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata.expression' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata.index' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.query' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.prefs' range='1.1.1'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'>
          <description>
            org.eclipse.equinox.p2.metadata.repository
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.metadata.repository' version='1.4.0.v20210315-2228'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.metadata.repository;singleton:=true&#xA;Bundle-Version: 1.4.0.v20210315-2228
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.publisher' version='1.6.0.v20210322-0909' generation='2'>
      <update id='org.eclipse.equinox.p2.publisher' range='[0.0.0,1.6.0.v20210322-0909)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.bundleName' value='Equinox Provisioning Publisher Infrastructure'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='9'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.publisher' version='1.6.0.v20210322-0909'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.publisher' version='1.6.0.v20210322-0909'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.publisher' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.publisher' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.publisher.actions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.spi.p2.publisher' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.p2.publisher' version='1.6.0.v20210322-0909'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='26'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.osgi' range='3.8.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.app' range='1.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.artifact.processors.checksum' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.artifact.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.artifact.repository.simple' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.expression' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.index' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.repository.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata' range='[2.4.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata.expression' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata.index' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.query' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.resolver' range='1.2.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.6.0'/>
        <required namespace='java.package' name='org.osgi.service.application' range='1.1.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'>
          <description>
            org.eclipse.equinox.p2.publisher
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.publisher' version='1.6.0.v20210322-0909'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.publisher;singleton:=true&#xA;Bundle-Version: 1.6.0.v20210322-0909
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.publisher.eclipse' version='1.5.0.v20230330-1254' generation='2'>
      <update id='org.eclipse.equinox.p2.publisher.eclipse' range='[0.0.0,1.5.0.v20230330-1254)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.bundleName' value='Equinox Provisioning Publisher for Eclipse'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='11'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.publisher.eclipse' version='1.5.0.v20230330-1254'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.publisher.eclipse' version='1.5.0.v20230330-1254'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.publisher.compatibility' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.publisher.eclipse' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.publisher.eclipse' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.pde.internal.build.publisher' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.pde.internal.publishing' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.pde.internal.swt.tools' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.p2.publisher.eclipse' version='1.5.0.v20230330-1254'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='37'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.5.0,4.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.app' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.frameworkadmin' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.frameworkadmin.equinox' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.frameworkadmin.utils' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.artifact.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.publisher' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.frameworkadmin' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core.spi' range='[2.1.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata' range='[2.4.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata.expression' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.publisher' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.publisher.actions' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.query' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.simpleconfigurator.manipulator' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.spi.p2.publisher' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.util' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='1.3.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.environment' range='1.1.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.pluginconversion' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.resolver' range='1.5.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.framework.wiring' range='1.2.0'/>
        <required namespace='java.package' name='org.osgi.resource' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.service.application' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='1.2.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.equinox.p2.publisher.eclipse
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.publisher.eclipse' version='1.5.0.v20230330-1254'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.publisher.eclipse;singleton:=true&#xA;Bundle-Version: 1.5.0.v20230330-1254
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.repository' version='2.5.0.v20201013-0853' generation='2'>
      <update id='org.eclipse.equinox.p2.repository' range='[0.0.0,2.5.0.v20201013-0853)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.pluginName' value='Equinox Provisioning Repository'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='15'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.repository' version='2.5.0.v20201013-0853'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.repository' version='2.5.0.v20201013-0853'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.persistence' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.repository' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.repository.helpers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.repository' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.repository' version='2.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact' version='2.3.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact.spi' version='2.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata' version='2.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata.spi' version='2.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.repository.spi' version='2.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.p2.repository' version='2.5.0.v20201013-0853'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='23'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='3.3.0'/>
        <required namespace='java.package' name='javax.crypto' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.jobs' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.preferences' range='3.2.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.repository.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.core.eventbus' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata' range='[2.4.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata.expression' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.query' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.security.storage' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.6.0'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='1.2.0'/>
        <required namespace='java.package' name='org.osgi.service.prefs' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.4.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'>
          <description>
            org.eclipse.equinox.p2.repository
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.repository' version='2.5.0.v20201013-0853'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.repository;singleton:=true&#xA;Bundle-Version: 2.5.0.v20201013-0853
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.repository.tools' version='2.3.0.v20210325-0750' generation='2'>
      <update id='org.eclipse.equinox.p2.repository.tools' range='[0.0.0,2.3.0.v20210325-0750)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.bundleName' value='Equinox Provisioning Repository Tools'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='11'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.repository.tools' version='2.3.0.v20210325-0750'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.repository.tools' version='2.3.0.v20210325-0750'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.internal.repository.comparator' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.internal.repository.mirroring' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.internal.repository.tools' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.internal.repository.tools.analyzer' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.repository.tools.analyzer' version='2.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.repository.tools.comparator' version='2.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.p2.repository.tools' version='2.3.0.v20210325-0750'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='35'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='3.3.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.tukaani.xz' range='1.3.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.app' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.frameworkadmin' range='2.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.artifact.processors.checksum' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.artifact.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.artifact.repository.simple' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.director' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.engine' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.engine.phases' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.persistence' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.publisher.eclipse' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.repository.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.director' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.engine' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.engine.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata.expression' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.planner' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.publisher.eclipse' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.query' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact' range='[2.3.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.simpleconfigurator.manipulator' range='2.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.4.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'>
          <description>
            org.eclipse.equinox.p2.repository.tools
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.repository.tools' version='2.3.0.v20210325-0750'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.repository.tools;singleton:=true&#xA;Bundle-Version: 2.3.0.v20210325-0750
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.touchpoint.eclipse' version='2.3.0.v20210315-2228' generation='2'>
      <update id='org.eclipse.equinox.p2.touchpoint.eclipse' range='[0.0.0,2.3.0.v20210315-2228)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.pluginName' value='Equinox Provisioning Eclipse Touchpoint'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='9'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.touchpoint.eclipse' version='2.3.0.v20210315-2228'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.touchpoint.eclipse' version='2.3.0.v20210315-2228'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.touchpoint.eclipse' version='2.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.touchpoint.eclipse.actions' version='2.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.update' version='2.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.touchpoint.eclipse.query' version='2.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.p2.touchpoint.eclipse' version='2.3.0.v20210315-2228'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='35'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.5.0,4.0.0)'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.frameworkadmin' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.engine' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.garbagecollector' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.frameworkadmin' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.simpleconfigurator.manipulator' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core.spi' range='[2.1.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.engine' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.engine.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata.expression' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.planner' range='[2.0.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.publisher' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.publisher.eclipse' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.query' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact' range='[2.3.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.simpleconfigurator.manipulator' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.environment' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.resolver' range='1.2.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.prefs' range='1.1.1'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.4.0'/>
        <required namespace='java.package' name='org.w3c.dom' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'>
          <description>
            org.eclipse.equinox.p2.touchpoint.eclipse
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.touchpoint.eclipse' version='2.3.0.v20210315-2228'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.touchpoint.eclipse;singleton:=true&#xA;Bundle-Version: 2.3.0.v20210315-2228
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.touchpoint.natives' version='1.4.0.v20210326-2048' generation='2'>
      <update id='org.eclipse.equinox.p2.touchpoint.natives' range='[0.0.0,1.4.0.v20210326-2048)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.pluginName' value='Equinox Provisioning Native Touchpoint'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='18'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.touchpoint.natives' version='1.2.200.v20210326-2048'/>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.touchpoint.natives' version='1.3.0.v20210326-2048'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.p2.touchpoint.natives' version='1.4.0.v20210326-2048'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.touchpoint.natives' version='1.3.600.v20210326-2048'/>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.touchpoint.natives' version='1.2.100.v20210326-2048'/>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.touchpoint.natives' version='1.3.500.v20210326-2048'/>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.touchpoint.natives' version='1.2.0.v20210326-2048'/>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.touchpoint.natives' version='1.3.100.v20210326-2048'/>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.touchpoint.natives' version='1.3.400.v20210326-2048'/>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.touchpoint.natives' version='1.4.0.v20210326-2048'/>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.touchpoint.natives' version='1.3.200.v20210326-2048'/>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.touchpoint.natives' version='1.3.300.v20210326-2048'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.touchpoint.natives' version='1.4.0.v20210326-2048'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.touchpoint.natives.actions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.touchpoint.natives' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.touchpoint.natives' version='1.1.100.v20140523-0116'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='17'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.app' range='1.3.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.engine' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.engine' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.engine.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata.expression' range='2.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.query' range='2.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.environment' range='1.3.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='1.2.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'>
          <description>
            org.eclipse.equinox.p2.touchpoint.natives
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.touchpoint.natives' version='1.4.0.v20210326-2048'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.touchpoint.natives;singleton:=true&#xA;Bundle-Version: 1.4.0.v20210326-2048
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.transport.ecf' version='1.2.0.v20180222-0922' singleton='false' generation='2'>
      <update id='org.eclipse.equinox.p2.transport.ecf' range='[0.0.0,1.2.0.v20180222-0922)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.pluginName' value='Equinox Provisioning ECF based Transport'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.transport.ecf' version='1.2.0.v20180222-0922'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.transport.ecf' version='1.2.0.v20180222-0922'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.transport.ecf' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.p2.transport.ecf' version='1.2.0.v20180222-0922'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='12'>
        <required namespace='osgi.bundle' name='org.eclipse.ecf' range='3.1.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.ecf.filetransfer' range='4.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.ecf.provider.filetransfer' range='3.1.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.p2.core' range='2.0.100'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.p2.repository' range='2.1.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='3.6.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.jobs' range='3.5.100'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.6.0'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='1.2.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.5.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.eclipse.equinox.p2.transport.ecf
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.transport.ecf' version='1.2.0.v20180222-0922'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.transport.ecf&#xA;Bundle-Version: 1.2.0.v20180222-0922
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.updatechecker' version='1.3.0.v20210315-2228' generation='2'>
      <update id='org.eclipse.equinox.p2.updatechecker' range='[0.0.0,1.3.0.v20210315-2228)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.pluginName' value='Equinox Provisioning Update Checker'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.updatechecker' version='1.3.0.v20210315-2228'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.updatechecker' version='1.3.0.v20210315-2228'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.updatechecker' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.updatechecker' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.p2.updatechecker' version='1.3.0.v20210315-2228'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='11'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.3.0,4.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.engine' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.planner' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.query' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata' range='[2.0.0,3.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'>
          <description>
            org.eclipse.equinox.p2.updatechecker
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.updatechecker' version='1.3.0.v20210315-2228'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.updatechecker;singleton:=true&#xA;Bundle-Version: 1.3.0.v20210315-2228
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.updatesite' version='1.2.0.v20210322-0909' generation='2'>
      <update id='org.eclipse.equinox.p2.updatesite' range='[0.0.0,1.2.0.v20210322-0909)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.pluginName' value='Equinox Provisioning Legacy Update Site Support'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.updatesite' version='1.2.0.v20210322-0909'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.updatesite' version='1.2.0.v20210322-0909'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.updatesite' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.updatesite.artifact' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.updatesite.metadata' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.p2.updatesite' version='1.2.0.v20210322-0909'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='31'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.7.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.p2.metadata.repository' range='0.1.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.p2.artifact.repository' range='0.1.0'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.app' range='1.1.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.artifact.repository.simple' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.publisher.eclipse' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata' range='[2.4.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata.expression' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.publisher' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.publisher.actions' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.publisher.eclipse' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.query' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.spi.p2.publisher' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.resolver' range='1.2.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.w3c.dom' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax.helpers' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'>
          <description>
            org.eclipse.equinox.p2.updatesite
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.updatesite' version='1.2.0.v20210322-0909'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.updatesite;singleton:=true&#xA;Bundle-Version: 1.2.0.v20210322-0909
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.preferences' version='3.11.0.v20240210-0844' generation='2'>
      <update id='org.eclipse.equinox.preferences' range='[0.0.0,3.11.0.v20240210-0844)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.pluginName' value='Eclipse Preferences Mechanism'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.preferences' version='3.11.0.v20240210-0844'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.preferences' version='3.11.0.v20240210-0844'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.preferences' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.preferences.exchange' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime.preferences' version='3.5.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.preferences' version='3.11.0.v20240210-0844'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='12'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.18.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='[3.2.0,4.0.0)' optional='true' greedy='false'/>
        <required namespace='osgi.bundle' name='org.osgi.service.prefs' range='[1.1.0,1.2.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.log' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.environment' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.equinox.preferences
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.preferences' version='3.11.0.v20240210-0844'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.preferences; singleton:=true&#xA;Bundle-Version: 3.11.0.v20240210-0844
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.registry' version='3.12.0.v20240213-1057' generation='2'>
      <update id='org.eclipse.equinox.registry' range='[0.0.0,3.12.0.v20240213-1057)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.pluginName' value='Extension Registry Support'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='12'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.registry' version='3.12.0.v20240213-1057'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.registry' version='3.12.0.v20240213-1057'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.adapter' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.registry' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.registry.osgi' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.registry.spi' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime' version='3.7.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime.dynamichelpers' version='3.4.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime.spi' version='3.4.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.registry' version='3.12.0.v20240213-1057'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='17'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.15.100,4.0.0)'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.jobs' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.console' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.environment' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.localization' range='1.1.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.resolver' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.storagemanager' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax.helpers' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.equinox.registry
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.registry' version='3.12.0.v20240213-1057'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.registry;singleton:=true&#xA;Bundle-Version: 3.12.0.v20240213-1057
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.security' version='1.4.600.v20250521-0413' generation='2'>
      <update id='org.eclipse.equinox.security' range='[0.0.0,1.4.600.v20250521-0413)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.pluginName' value='Equinox Java Authentication and Authorization Service (JAAS)'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='18'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.security' version='1.4.600.v20250521-0413'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.security' version='1.4.600.v20250521-0413'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.security.auth' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.security.auth.events' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.security.auth.ext.loader' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.security.auth.nls' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.security.credentials' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.security.storage' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.security.storage.friends' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.security.storage.provider' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.security.auth' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.security.auth.credentials' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.security.auth.module' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.security.storage' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.security.storage.provider' version='1.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.security' version='1.4.600.v20250521-0413'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='19'>
        <required namespace='java.package' name='javax.crypto' range='0.0.0'/>
        <required namespace='java.package' name='javax.crypto.spec' range='0.0.0'/>
        <required namespace='java.package' name='javax.security.auth' range='0.0.0'/>
        <required namespace='java.package' name='javax.security.auth.callback' range='0.0.0'/>
        <required namespace='java.package' name='javax.security.auth.login' range='0.0.0'/>
        <required namespace='java.package' name='javax.security.auth.spi' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.internal.runtime' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.runtime' range='[3.7.0,4.0.0)'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.jobs' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.preferences' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.log' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.environment' range='[1.1.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='[1.1.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.6.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.service.prefs' range='[1.1.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='[1.5.0,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.equinox.security
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.security' version='1.4.600.v20250521-0413'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.security;singleton:=true&#xA;Bundle-Version: 1.4.600.v20250521-0413
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.simpleconfigurator' version='1.5.200.v20240209-1053' generation='2'>
      <update id='org.eclipse.equinox.simpleconfigurator' range='[0.0.0,1.5.200.v20240209-1053)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.bundleName' value='Simple Configurator'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='9'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.simpleconfigurator' version='1.5.200.v20240209-1053'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.simpleconfigurator' version='1.5.200.v20240209-1053'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.provisional.configurator' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.simpleconfigurator' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.simpleconfigurator.console' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.simpleconfigurator.utils' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.simpleconfigurator' version='1.5.200.v20240209-1053'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='14'>
        <required namespace='java.package' name='org.eclipse.osgi.framework.console' range='1.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.report.resolution' range='[1.0.0,2.0.0]'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='1.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.framework.hooks.resolver' range='[1.0.0,2.0.0]'/>
        <required namespace='java.package' name='org.osgi.framework.namespace' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.framework.startlevel' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.framework.wiring' range='1.2.0'/>
        <required namespace='java.package' name='org.osgi.resource' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='1.2.0'/>
        <required namespace='java.package' name='org.osgi.service.resolver' range='[1.1.0,2.0.0]'/>
        <required namespace='java.package' name='org.osgi.service.startlevel' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.3.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.equinox.simpleconfigurator
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.simpleconfigurator' version='1.5.200.v20240209-1053'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.simpleconfigurator;singleton:=true&#xA;Bundle-Version: 1.5.200.v20240209-1053
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.simpleconfigurator.manipulator' version='2.3.100.v20240201-0843' generation='2'>
      <update id='org.eclipse.equinox.simpleconfigurator.manipulator' range='[0.0.0,2.3.100.v20240201-0843)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.bundleName' value='Simple Configurator Manipulator'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.simpleconfigurator.manipulator' version='2.3.100.v20240201-0843'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.simpleconfigurator.manipulator' version='2.3.100.v20240201-0843'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.simpleconfigurator.manipulator' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.simpleconfigurator.manipulator' version='2.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.simpleconfigurator.manipulator' version='2.3.100.v20240201-0843'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='10'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='3.5.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.frameworkadmin' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.frameworkadmin.equinox' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.frameworkadmin.utils' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.configuratormanipulator' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.frameworkadmin' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.simpleconfigurator' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.simpleconfigurator.utils' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.equinox.simpleconfigurator.manipulator
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.simpleconfigurator.manipulator' version='2.3.100.v20240201-0843'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.simpleconfigurator.manipulator;singleton:=true&#xA;Bundle-Version: 2.3.100.v20240201-0843
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.util' version='1.1.300.v20190714-1852' singleton='false' generation='2'>
      <update id='org.eclipse.equinox.util' range='[0.0.0,1.1.300.v20190714-1852)' severity='0'/>
      <properties size='6'>
        <property name='df_LT.bundleVendor' value='Eclipse.org - Equinox'/>
        <property name='df_LT.bundleName' value='Equinox Util Bundle'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.description' value='The Equinox Util Bundle contains services to facilitate bundle developers in their programming, and to lighten resource usage at runtime.'/>
        <property name='org.eclipse.equinox.p2.provider' value='%bundleVendor'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='16'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.util' version='1.1.300.v20190714-1852'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.util' version='1.1.300.v20190714-1852'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.util.event' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.util.hash' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.util.impl.tpt' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.util.impl.tpt.threadpool' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.util.impl.tpt.timer' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.util.pool' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.util.ref' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.util.security' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.util.threadpool' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.util.timer' version='1.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.util' version='1.1.300.v20190714-1852'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='5'>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.cm' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.service.log' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.2.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.7))'>
          <description>
            org.eclipse.equinox.util
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.util' version='1.1.300.v20190714-1852'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.util&#xA;Bundle-Version: 1.1.300.v20190714-1852
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.osgi' version='3.19.0.v20240213-1246' generation='2'>
      <update id='org.eclipse.osgi' range='[0.0.0,3.19.0.v20240213-1246)' severity='0'/>
      <properties size='7'>
        <property name='df_LT.eclipse.org' value='Eclipse.org - Equinox'/>
        <property name='df_LT.systemBundle' value='OSGi System Bundle'/>
        <property name='org.eclipse.equinox.p2.name' value='%systemBundle'/>
        <property name='org.eclipse.equinox.p2.description' value='%systemBundle'/>
        <property name='org.eclipse.equinox.p2.provider' value='%eclipse.org'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='http://www.eclipse.org'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='systembundle'/>
      </properties>
      <provides size='97'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi' version='3.19.0.v20240213-1246'/>
        <provided namespace='osgi.bundle' name='org.eclipse.osgi' version='3.19.0.v20240213-1246'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime.adaptor' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime.internal.adaptor' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.log' version='1.1.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.container' version='1.7.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.container.builders' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.container.namespaces' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.framework.console' version='1.1.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.framework.eventmgr' version='1.2.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.framework.internal.reliablefile' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.framework.log' version='1.1.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.framework.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.debug' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.framework' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.hookregistry' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.loader' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.loader.buddy' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.loader.classpath' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.loader.sources' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.location' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.messages' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.provisional.service.security' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.provisional.verifier' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.service.security' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.serviceregistry' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.signedcontent' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.url' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.launch' version='1.1.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.report.resolution' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.datalocation' version='1.4.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.debug' version='1.2.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.environment' version='1.4.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.localization' version='1.1.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.pluginconversion' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.resolver' version='1.6.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.runnable' version='1.1.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.security' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.urlconversion' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.signedcontent' version='1.1.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.storage' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.storage.bundlefile' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.storage.url.reference' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.storagemanager' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.util' version='1.1.0'/>
        <provided namespace='java.package' name='org.osgi.dto' version='1.1.1'/>
        <provided namespace='java.package' name='org.osgi.framework' version='1.10.0'/>
        <provided namespace='java.package' name='org.osgi.framework.connect' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.framework.dto' version='1.8.0'/>
        <provided namespace='java.package' name='org.osgi.framework.hooks.bundle' version='1.1.0'/>
        <provided namespace='java.package' name='org.osgi.framework.hooks.resolver' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.framework.hooks.service' version='1.1.0'/>
        <provided namespace='java.package' name='org.osgi.framework.hooks.weaving' version='1.1.0'/>
        <provided namespace='java.package' name='org.osgi.framework.launch' version='1.2.0'/>
        <provided namespace='java.package' name='org.osgi.framework.namespace' version='1.2.0'/>
        <provided namespace='java.package' name='org.osgi.framework.startlevel' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.framework.startlevel.dto' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.framework.wiring' version='1.2.0'/>
        <provided namespace='java.package' name='org.osgi.framework.wiring.dto' version='1.3.0'/>
        <provided namespace='java.package' name='org.osgi.resource' version='1.0.1'/>
        <provided namespace='java.package' name='org.osgi.resource.dto' version='1.0.1'/>
        <provided namespace='java.package' name='org.osgi.service.condition' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.service.condpermadmin' version='1.1.2'/>
        <provided namespace='java.package' name='org.osgi.service.log' version='1.5.0'/>
        <provided namespace='java.package' name='org.osgi.service.log.admin' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.service.packageadmin' version='1.2.1'/>
        <provided namespace='java.package' name='org.osgi.service.permissionadmin' version='1.2.1'/>
        <provided namespace='java.package' name='org.osgi.service.resolver' version='1.1.1'/>
        <provided namespace='java.package' name='org.osgi.service.startlevel' version='1.1.1'/>
        <provided namespace='java.package' name='org.osgi.service.url' version='1.0.1'/>
        <provided namespace='java.package' name='org.osgi.util.tracker' version='1.5.4'/>
        <provided namespace='osgi.identity' name='org.eclipse.osgi' version='3.19.0.v20240213-1246'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.19.0.v20240213-1246-1' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.osgi.service.log.LogReaderService,org.eclipse.equinox.log.ExtendedLogReaderService' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.19.0.v20240213-1246-2' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.osgi.service.log.LoggerFactory,org.osgi.service.log.LogService,org.eclipse.equinox.log.ExtendedLogService' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.19.0.v20240213-1246-3' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.osgi.service.log.admin.LoggerAdmin' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.19.0.v20240213-1246-4' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.eclipse.osgi.framework.log.FrameworkLog' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.19.0.v20240213-1246-5' version='0.0.0'>
          <properties size='2'>
            <property name='objectClass' value='org.eclipse.osgi.service.datalocation.Location' type='List'/>
            <property name='type' value='osgi.user.area'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.19.0.v20240213-1246-6' version='0.0.0'>
          <properties size='2'>
            <property name='objectClass' value='org.eclipse.osgi.service.datalocation.Location' type='List'/>
            <property name='type' value='osgi.instance.area'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.19.0.v20240213-1246-7' version='0.0.0'>
          <properties size='2'>
            <property name='objectClass' value='org.eclipse.osgi.service.datalocation.Location' type='List'/>
            <property name='type' value='osgi.configuration.area'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.19.0.v20240213-1246-8' version='0.0.0'>
          <properties size='2'>
            <property name='objectClass' value='org.eclipse.osgi.service.datalocation.Location' type='List'/>
            <property name='type' value='osgi.install.area'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.19.0.v20240213-1246-9' version='0.0.0'>
          <properties size='2'>
            <property name='objectClass' value='org.eclipse.osgi.service.datalocation.Location' type='List'/>
            <property name='type' value='eclipse.home.location'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.19.0.v20240213-1246-10' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.eclipse.osgi.service.environment.EnvironmentInfo' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.19.0.v20240213-1246-11' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.osgi.service.packageadmin.PackageAdmin' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.19.0.v20240213-1246-12' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.osgi.service.startlevel.StartLevel' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.19.0.v20240213-1246-13' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.osgi.service.permissionadmin.PermissionAdmin' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.19.0.v20240213-1246-14' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.osgi.service.condpermadmin.ConditionalPermissionAdmin' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.19.0.v20240213-1246-15' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.osgi.service.resolver.Resolver' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.19.0.v20240213-1246-16' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.eclipse.osgi.service.debug.DebugOptions' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.19.0.v20240213-1246-17' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.eclipse.osgi.service.urlconversion.URLConverter' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.19.0.v20240213-1246-18' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.eclipse.osgi.service.localization.BundleLocalization' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.19.0.v20240213-1246-19' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.eclipse.osgi.service.security.TrustEngine' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.19.0.v20240213-1246-20' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.eclipse.osgi.signedcontent.SignedContentFactory' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.19.0.v20240213-1246-21' version='0.0.0'>
          <properties size='2'>
            <property name='objectClass' value='org.osgi.service.condition.Condition' type='List'/>
            <property name='osgi.condition.id' value='true'/>
          </properties>
        </provided>
        <provided namespace='osgi.serviceloader' name='org.osgi.framework.connect.ConnectFrameworkFactory' version='0.0.0'/>
        <provided namespace='osgi.serviceloader' name='org.osgi.framework.launch.FrameworkFactory' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <requiredProperties namespace='osgi.ee' match='(&amp;(version=1.8)(|(osgi.ee=JavaSE)(osgi.ee=JavaSE/compact1)))'>
          <description>
            org.eclipse.osgi
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.osgi' version='3.19.0.v20240213-1246'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.osgi; singleton:=true&#xA;Bundle-Version: 3.19.0.v20240213-1246
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.osgi.compatibility.state' version='1.0.200.v20160504-1419' singleton='false' generation='2'>
      <update id='org.eclipse.osgi.compatibility.state' range='[0.0.0,1.0.200.v20160504-1419)' severity='0'/>
      <properties size='4'>
        <property name='df_LT.Bundle-Name' value='Equinox State and Resolver Compatibility Fragment'/>
        <property name='df_LT.Bundle-Vendor' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%Bundle-Name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%Bundle-Vendor'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.compatibility.state' version='1.0.200.v20160504-1419'/>
        <provided namespace='osgi.bundle' name='org.eclipse.osgi.compatibility.state' version='1.0.200.v20160504-1419'/>
        <provided namespace='osgi.identity' name='org.eclipse.osgi.compatibility.state' version='1.0.200.v20160504-1419'>
          <properties size='1'>
            <property name='type' value='osgi.fragment'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='osgi.fragment' name='org.eclipse.osgi' version='1.0.200.v20160504-1419'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.osgi' range='3.10.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.6))'>
          <description>
            org.eclipse.osgi.compatibility.state
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.osgi.compatibility.state' version='1.0.200.v20160504-1419'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.osgi.compatibility.state&#xA;Bundle-Version: 1.0.200.v20160504-1419&#xA;Fragment-Host: org.eclipse.osgi;bundle-version=&quot;3.10.0&quot;
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.osgi.services' version='3.12.0.v20231218-2126' singleton='false' generation='2'>
      <update id='org.eclipse.osgi.services' range='[0.0.0,3.12.0.v20231218-2126)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.osgiServicesDes' value='OSGi Service Platform Release 4.2.0 Service Interfaces and Classes'/>
        <property name='df_LT.osgiServices' value='OSGi Release 4.2.0 Services'/>
        <property name='df_LT.eclipse.org' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%osgiServices'/>
        <property name='org.eclipse.equinox.p2.description' value='%osgiServicesDes'/>
        <property name='org.eclipse.equinox.p2.provider' value='%eclipse.org'/>
        <property name='org.eclipse.equinox.p2.contact' value='www.eclipse.org'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='http://www.eclipse.org'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.services' version='3.12.0.v20231218-2126'/>
        <provided namespace='osgi.bundle' name='org.eclipse.osgi.services' version='3.12.0.v20231218-2126'/>
        <provided namespace='java.package' name='org.osgi.service.component.annotations' version='1.3.0'/>
        <provided namespace='java.package' name='org.osgi.service.log' version='1.5.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.osgi.services' version='3.12.0.v20231218-2126'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='15'>
        <required namespace='osgi.bundle' name='org.osgi.service.upnp' range='[1.2.0,1.3.0)'/>
        <required namespace='osgi.bundle' name='org.osgi.service.device' range='[1.1.0,1.2.0)'/>
        <required namespace='java.package' name='javax.servlet' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='osgi.bundle' name='org.osgi.service.http.whiteboard' range='[1.1.0,2.0.0)'/>
        <required namespace='osgi.bundle' name='org.osgi.service.event' range='[1.4.0,1.5.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.http.service.api' range='[1.2.0,2.0.0)'/>
        <required namespace='java.package' name='javax.servlet.http' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='osgi.bundle' name='org.osgi.service.wireadmin' range='[1.0.0,1.1.0)'/>
        <required namespace='osgi.bundle' name='org.osgi.service.provisioning' range='[1.2.0,1.3.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.eclipse.osgi.services
          </description>
        </requiredProperties>
        <required namespace='osgi.bundle' name='org.osgi.service.component' range='[1.5.0,1.6.0)'/>
        <required namespace='osgi.bundle' name='org.osgi.service.useradmin' range='[1.1.0,1.2.0)'/>
        <required namespace='osgi.bundle' name='org.osgi.service.metatype' range='[1.4.0,1.5.0)'/>
        <required namespace='java.package' name='org.osgi.service.log' range='[1.5.0,1.6.0)'/>
        <required namespace='osgi.bundle' name='org.osgi.service.cm' range='[1.6.0,1.7.0)'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.osgi.services' version='3.12.0.v20231218-2126'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.osgi.services;deprecated:=&quot;Deprecated in favour of the original jars published by the OSGi working-group.&quot;&#xA;Bundle-Version: 3.12.0.v20231218-2126
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.osgi.service.cm' version='1.6.1.202109301733' singleton='false' generation='2'>
      <update id='org.osgi.service.cm' range='[0.0.0,1.6.1.202109301733)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='org.osgi:org.osgi.service.cm'/>
        <property name='org.eclipse.equinox.p2.description' value='OSGi Companion Code for org.osgi.service.cm Version 1.6.1'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse Foundation'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://docs.osgi.org/'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.cm' version='1.6.1.202109301733'/>
        <provided namespace='osgi.bundle' name='org.osgi.service.cm' version='1.6.1.202109301733'/>
        <provided namespace='java.package' name='org.osgi.service.cm' version='1.6.1'/>
        <provided namespace='java.package' name='org.osgi.service.cm.annotations' version='1.6.1'/>
        <provided namespace='osgi.identity' name='org.osgi.service.cm' version='1.6.1.202109301733'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='java.package' name='org.osgi.framework' range='[1.8.0,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE/compact1)(version=1.8))'>
          <description>
            org.osgi.service.cm
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.osgi.service.cm' version='1.6.1.202109301733'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.osgi.service.cm&#xA;Bundle-Version: 1.6.1.202109301733
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.osgi.service.component' version='1.5.1.202212101352' singleton='false' generation='2'>
      <update id='org.osgi.service.component' range='[0.0.0,1.5.1.202212101352)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='org.osgi:org.osgi.service.component'/>
        <property name='org.eclipse.equinox.p2.description' value='OSGi Companion Code for org.osgi.service.component Version 1.5.1'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse Foundation'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://docs.osgi.org/'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.component' version='1.5.1.202212101352'/>
        <provided namespace='osgi.bundle' name='org.osgi.service.component' version='1.5.1.202212101352'/>
        <provided namespace='java.package' name='org.osgi.service.component' version='1.5.1'/>
        <provided namespace='java.package' name='org.osgi.service.component.propertytypes' version='1.5.0'/>
        <provided namespace='java.package' name='org.osgi.service.component.runtime' version='1.5.0'/>
        <provided namespace='java.package' name='org.osgi.service.component.runtime.dto' version='1.5.0'/>
        <provided namespace='osgi.identity' name='org.osgi.service.component' version='1.5.1.202212101352'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='6'>
        <required namespace='java.package' name='org.osgi.dto' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.8.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework.dto' range='[1.8.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.service.component.runtime.dto' range='[1.5.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.util.promise' range='[1.0.0,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE/compact1)(version=1.8))'>
          <description>
            org.osgi.service.component
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.osgi.service.component' version='1.5.1.202212101352'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.osgi.service.component&#xA;Bundle-Version: 1.5.1.202212101352
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.osgi.service.device' version='1.1.1.202109301733' singleton='false' generation='2'>
      <update id='org.osgi.service.device' range='[0.0.0,1.1.1.202109301733)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='org.osgi:org.osgi.service.device'/>
        <property name='org.eclipse.equinox.p2.description' value='OSGi Companion Code for org.osgi.service.device Version 1.1.1'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse Foundation'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://docs.osgi.org/'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.device' version='1.1.1.202109301733'/>
        <provided namespace='osgi.bundle' name='org.osgi.service.device' version='1.1.1.202109301733'/>
        <provided namespace='java.package' name='org.osgi.service.device' version='1.1.1'/>
        <provided namespace='osgi.identity' name='org.osgi.service.device' version='1.1.1.202109301733'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='java.package' name='org.osgi.framework' range='[1.8.0,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE/compact1)(version=1.8))'>
          <description>
            org.osgi.service.device
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.osgi.service.device' version='1.1.1.202109301733'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.osgi.service.device&#xA;Bundle-Version: 1.1.1.202109301733
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.osgi.service.event' version='1.4.1.202109301733' singleton='false' generation='2'>
      <update id='org.osgi.service.event' range='[0.0.0,1.4.1.202109301733)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='org.osgi:org.osgi.service.event'/>
        <property name='org.eclipse.equinox.p2.description' value='OSGi Companion Code for org.osgi.service.event Version 1.4.1'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse Foundation'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://docs.osgi.org/'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.event' version='1.4.1.202109301733'/>
        <provided namespace='osgi.bundle' name='org.osgi.service.event' version='1.4.1.202109301733'/>
        <provided namespace='java.package' name='org.osgi.service.event' version='1.4.1'/>
        <provided namespace='java.package' name='org.osgi.service.event.annotations' version='1.4.1'/>
        <provided namespace='java.package' name='org.osgi.service.event.propertytypes' version='1.4.0'/>
        <provided namespace='osgi.identity' name='org.osgi.service.event' version='1.4.1.202109301733'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='java.package' name='org.osgi.framework' range='[1.8.0,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE/compact1)(version=1.8))'>
          <description>
            org.osgi.service.event
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.osgi.service.event' version='1.4.1.202109301733'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.osgi.service.event&#xA;Bundle-Version: 1.4.1.202109301733
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.osgi.service.http.whiteboard' version='1.1.1.202109301733' singleton='false' generation='2'>
      <update id='org.osgi.service.http.whiteboard' range='[0.0.0,1.1.1.202109301733)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='org.osgi:org.osgi.service.http.whiteboard'/>
        <property name='org.eclipse.equinox.p2.description' value='OSGi Companion Code for org.osgi.service.http.whiteboard Version 1.1.1'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse Foundation'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://docs.osgi.org/'/>
      </properties>
      <provides size='10'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.http.whiteboard' version='1.1.1.202109301733'/>
        <provided namespace='osgi.bundle' name='org.osgi.service.http.whiteboard' version='1.1.1.202109301733'/>
        <provided namespace='java.package' name='org.osgi.service.http.context' version='1.1.0'/>
        <provided namespace='java.package' name='org.osgi.service.http.runtime' version='1.1.0'/>
        <provided namespace='java.package' name='org.osgi.service.http.runtime.dto' version='1.1.0'/>
        <provided namespace='java.package' name='org.osgi.service.http.whiteboard' version='1.1.1'/>
        <provided namespace='java.package' name='org.osgi.service.http.whiteboard.annotations' version='1.1.1'/>
        <provided namespace='java.package' name='org.osgi.service.http.whiteboard.propertytypes' version='1.1.0'/>
        <provided namespace='osgi.identity' name='org.osgi.service.http.whiteboard' version='1.1.1.202109301733'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='8'>
        <required namespace='java.package' name='javax.servlet' range='0.0.0'/>
        <required namespace='java.package' name='javax.servlet.http' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.dto' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.8.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework.dto' range='[1.8.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.service.http.runtime.dto' range='[1.1.0,2.0.0)'/>
        <requiredProperties namespace='osgi.contract' match='(&amp;(osgi.contract=JavaServlet)(version=3.1.0))'>
          <description>
            org.osgi.service.http.whiteboard
          </description>
        </requiredProperties>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE/compact1)(version=1.8))'>
          <description>
            org.osgi.service.http.whiteboard
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.osgi.service.http.whiteboard' version='1.1.1.202109301733'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.osgi.service.http.whiteboard&#xA;Bundle-Version: 1.1.1.202109301733
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.osgi.service.metatype' version='1.4.1.202109301733' singleton='false' generation='2'>
      <update id='org.osgi.service.metatype' range='[0.0.0,1.4.1.202109301733)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='org.osgi:org.osgi.service.metatype'/>
        <property name='org.eclipse.equinox.p2.description' value='OSGi Companion Code for org.osgi.service.metatype Version 1.4.1'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse Foundation'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://docs.osgi.org/'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.metatype' version='1.4.1.202109301733'/>
        <provided namespace='osgi.bundle' name='org.osgi.service.metatype' version='1.4.1.202109301733'/>
        <provided namespace='java.package' name='org.osgi.service.metatype' version='1.4.1'/>
        <provided namespace='osgi.identity' name='org.osgi.service.metatype' version='1.4.1.202109301733'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='java.package' name='org.osgi.framework' range='[1.8.0,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE/compact1)(version=1.8))'>
          <description>
            org.osgi.service.metatype
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.osgi.service.metatype' version='1.4.1.202109301733'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.osgi.service.metatype&#xA;Bundle-Version: 1.4.1.202109301733
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.osgi.service.permissionadmin' version='1.2.1.202007221806' singleton='false' generation='2'>
      <update id='org.osgi.service.permissionadmin' range='[0.0.0,1.2.1.202007221806)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='org.osgi:org.osgi.service.permissionadmin'/>
        <property name='org.eclipse.equinox.p2.description' value='OSGi Companion Code for org.osgi.service.permissionadmin Version 1.2.1'/>
        <property name='org.eclipse.equinox.p2.provider' value='OSGi Alliance https://www.osgi.org/'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://www.osgi.org/'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.permissionadmin' version='1.2.1.202007221806'/>
        <provided namespace='osgi.bundle' name='org.osgi.service.permissionadmin' version='1.2.1.202007221806'/>
        <provided namespace='java.package' name='org.osgi.service.permissionadmin' version='1.2.1'/>
        <provided namespace='osgi.identity' name='org.osgi.service.permissionadmin' version='1.2.1.202007221806'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE/compact1)(version=1.8))'>
          <description>
            org.osgi.service.permissionadmin
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.osgi.service.permissionadmin' version='1.2.1.202007221806'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.osgi.service.permissionadmin&#xA;Bundle-Version: 1.2.1.202007221806
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.osgi.service.prefs' version='1.1.2.202109301733' singleton='false' generation='2'>
      <update id='org.osgi.service.prefs' range='[0.0.0,1.1.2.202109301733)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='org.osgi:org.osgi.service.prefs'/>
        <property name='org.eclipse.equinox.p2.description' value='OSGi Companion Code for org.osgi.service.prefs Version 1.1.2'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse Foundation'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://docs.osgi.org/'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.prefs' version='1.1.2.202109301733'/>
        <provided namespace='osgi.bundle' name='org.osgi.service.prefs' version='1.1.2.202109301733'/>
        <provided namespace='java.package' name='org.osgi.service.prefs' version='1.1.2'/>
        <provided namespace='osgi.identity' name='org.osgi.service.prefs' version='1.1.2.202109301733'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE/compact1)(version=1.8))'>
          <description>
            org.osgi.service.prefs
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.osgi.service.prefs' version='1.1.2.202109301733'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.osgi.service.prefs&#xA;Bundle-Version: 1.1.2.202109301733
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.osgi.service.provisioning' version='1.2.0.201505202024' singleton='false' generation='2'>
      <update id='org.osgi.service.provisioning' range='[0.0.0,1.2.0.201505202024)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='org.osgi:org.osgi.service.provisioning'/>
        <property name='org.eclipse.equinox.p2.description' value='OSGi Companion Code for org.osgi.service.provisioning Version 1.2.0.'/>
        <property name='org.eclipse.equinox.p2.provider' value='OSGi Alliance http://www.osgi.org/'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='http://www.osgi.org/'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.provisioning' version='1.2.0.201505202024'/>
        <provided namespace='osgi.bundle' name='org.osgi.service.provisioning' version='1.2.0.201505202024'/>
        <provided namespace='java.package' name='org.osgi.service.provisioning' version='1.2.0'/>
        <provided namespace='osgi.identity' name='org.osgi.service.provisioning' version='1.2.0.201505202024'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.2))'>
          <description>
            org.osgi.service.provisioning
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.osgi.service.provisioning' version='1.2.0.201505202024'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.osgi.service.provisioning&#xA;Bundle-Version: 1.2.0.201505202024
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.osgi.service.upnp' version='1.2.1.202109301733' singleton='false' generation='2'>
      <update id='org.osgi.service.upnp' range='[0.0.0,1.2.1.202109301733)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='org.osgi:org.osgi.service.upnp'/>
        <property name='org.eclipse.equinox.p2.description' value='OSGi Companion Code for org.osgi.service.upnp Version 1.2.1'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse Foundation'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://docs.osgi.org/'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.upnp' version='1.2.1.202109301733'/>
        <provided namespace='osgi.bundle' name='org.osgi.service.upnp' version='1.2.1.202109301733'/>
        <provided namespace='java.package' name='org.osgi.service.upnp' version='1.2.1'/>
        <provided namespace='osgi.identity' name='org.osgi.service.upnp' version='1.2.1.202109301733'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE/compact1)(version=1.8))'>
          <description>
            org.osgi.service.upnp
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.osgi.service.upnp' version='1.2.1.202109301733'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.osgi.service.upnp&#xA;Bundle-Version: 1.2.1.202109301733
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.osgi.service.useradmin' version='1.1.1.202109301733' singleton='false' generation='2'>
      <update id='org.osgi.service.useradmin' range='[0.0.0,1.1.1.202109301733)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='org.osgi:org.osgi.service.useradmin'/>
        <property name='org.eclipse.equinox.p2.description' value='OSGi Companion Code for org.osgi.service.useradmin Version 1.1.1'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse Foundation'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://docs.osgi.org/'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.useradmin' version='1.1.1.202109301733'/>
        <provided namespace='osgi.bundle' name='org.osgi.service.useradmin' version='1.1.1.202109301733'/>
        <provided namespace='java.package' name='org.osgi.service.useradmin' version='1.1.1'/>
        <provided namespace='osgi.identity' name='org.osgi.service.useradmin' version='1.1.1.202109301733'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='java.package' name='org.osgi.framework' range='[1.8.0,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE/compact1)(version=1.8))'>
          <description>
            org.osgi.service.useradmin
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.osgi.service.useradmin' version='1.1.1.202109301733'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.osgi.service.useradmin&#xA;Bundle-Version: 1.1.1.202109301733
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.osgi.service.wireadmin' version='1.0.2.202109301733' singleton='false' generation='2'>
      <update id='org.osgi.service.wireadmin' range='[0.0.0,1.0.2.202109301733)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='org.osgi:org.osgi.service.wireadmin'/>
        <property name='org.eclipse.equinox.p2.description' value='OSGi Companion Code for org.osgi.service.wireadmin Version 1.0.2'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse Foundation'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://docs.osgi.org/'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.wireadmin' version='1.0.2.202109301733'/>
        <provided namespace='osgi.bundle' name='org.osgi.service.wireadmin' version='1.0.2.202109301733'/>
        <provided namespace='java.package' name='org.osgi.service.wireadmin' version='1.0.2'/>
        <provided namespace='osgi.identity' name='org.osgi.service.wireadmin' version='1.0.2.202109301733'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='java.package' name='org.osgi.framework' range='[1.8.0,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE/compact1)(version=1.8))'>
          <description>
            org.osgi.service.wireadmin
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.osgi.service.wireadmin' version='1.0.2.202109301733'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.osgi.service.wireadmin&#xA;Bundle-Version: 1.0.2.202109301733
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.osgi.util.function' version='1.2.0.202109301733' singleton='false' generation='2'>
      <update id='org.osgi.util.function' range='[0.0.0,1.2.0.202109301733)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='org.osgi:org.osgi.util.function'/>
        <property name='org.eclipse.equinox.p2.description' value='OSGi Companion Code for org.osgi.util.function Version 1.2.0'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse Foundation'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://docs.osgi.org/'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.osgi.util.function' version='1.2.0.202109301733'/>
        <provided namespace='osgi.bundle' name='org.osgi.util.function' version='1.2.0.202109301733'/>
        <provided namespace='java.package' name='org.osgi.util.function' version='1.2.0'/>
        <provided namespace='osgi.identity' name='org.osgi.util.function' version='1.2.0.202109301733'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE/compact1)(version=1.8))'>
          <description>
            org.osgi.util.function
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.osgi.util.function' version='1.2.0.202109301733'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.osgi.util.function&#xA;Bundle-Version: 1.2.0.202109301733
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.osgi.util.promise' version='1.3.0.202212101352' singleton='false' generation='2'>
      <update id='org.osgi.util.promise' range='[0.0.0,1.3.0.202212101352)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='org.osgi:org.osgi.util.promise'/>
        <property name='org.eclipse.equinox.p2.description' value='OSGi Companion Code for org.osgi.util.promise Version 1.3.0'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse Foundation'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://docs.osgi.org/'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.osgi.util.promise' version='1.3.0.202212101352'/>
        <provided namespace='osgi.bundle' name='org.osgi.util.promise' version='1.3.0.202212101352'/>
        <provided namespace='java.package' name='org.osgi.util.promise' version='1.3.0'/>
        <provided namespace='osgi.identity' name='org.osgi.util.promise' version='1.3.0.202212101352'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='java.package' name='org.osgi.util.function' range='[1.1.0,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE/compact1)(version=1.8))'>
          <description>
            org.osgi.util.promise
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.osgi.util.promise' version='1.3.0.202212101352'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.osgi.util.promise&#xA;Bundle-Version: 1.3.0.202212101352
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.sat4j.core' version='2.3.5.v201308161310' singleton='false' generation='2'>
      <update id='org.sat4j.core' range='[0.0.0,2.3.5.v201308161310)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.bundleName' value='SAT4J Core'/>
        <property name='df_LT.providerName' value='Eclipse Orbit'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='21'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.sat4j.core' version='2.3.5.v201308161310'/>
        <provided namespace='osgi.bundle' name='org.sat4j.core' version='2.3.5.v201308161310'/>
        <provided namespace='java.package' name='org.sat4j' version='2.3.5.v20130525'/>
        <provided namespace='java.package' name='org.sat4j.core' version='2.3.5.v20130525'/>
        <provided namespace='java.package' name='org.sat4j.minisat' version='2.3.5.v20130525'/>
        <provided namespace='java.package' name='org.sat4j.minisat.constraints' version='2.3.5.v20130525'/>
        <provided namespace='java.package' name='org.sat4j.minisat.constraints.card' version='2.3.5.v20130525'/>
        <provided namespace='java.package' name='org.sat4j.minisat.constraints.cnf' version='2.3.5.v20130525'/>
        <provided namespace='java.package' name='org.sat4j.minisat.core' version='2.3.5.v20130525'/>
        <provided namespace='java.package' name='org.sat4j.minisat.learning' version='2.3.5.v20130525'/>
        <provided namespace='java.package' name='org.sat4j.minisat.orders' version='2.3.5.v20130525'/>
        <provided namespace='java.package' name='org.sat4j.minisat.restarts' version='2.3.5.v20130525'/>
        <provided namespace='java.package' name='org.sat4j.opt' version='2.3.5.v20130525'/>
        <provided namespace='java.package' name='org.sat4j.reader' version='2.3.5.v20130525'/>
        <provided namespace='java.package' name='org.sat4j.specs' version='2.3.5.v20130525'/>
        <provided namespace='java.package' name='org.sat4j.tools' version='2.3.5.v20130525'/>
        <provided namespace='java.package' name='org.sat4j.tools.encoding' version='2.3.5.v20130525'/>
        <provided namespace='java.package' name='org.sat4j.tools.xplain' version='2.3.5.v20130525'/>
        <provided namespace='osgi.identity' name='org.sat4j.core' version='2.3.5.v201308161310'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.5))'>
          <description>
            org.sat4j.core
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.sat4j.core' version='2.3.5.v201308161310'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.sat4j.core&#xA;Bundle-Version: 2.3.5.v201308161310
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.sat4j.pb' version='2.3.5.v201308161310' singleton='false' generation='2'>
      <update id='org.sat4j.pb' range='[0.0.0,2.3.5.v201308161310)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.bundleName' value='SAT4J Pseudo'/>
        <property name='df_LT.providerName' value='Eclipse Orbit'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='12'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.sat4j.pb' version='2.3.5.v201308161310'/>
        <provided namespace='osgi.bundle' name='org.sat4j.pb' version='2.3.5.v201308161310'/>
        <provided namespace='java.package' name='org.sat4j.pb' version='2.3.5.v20130525'/>
        <provided namespace='java.package' name='org.sat4j.pb.constraints' version='2.3.5.v20130525'/>
        <provided namespace='java.package' name='org.sat4j.pb.constraints.pb' version='2.3.5.v20130525'/>
        <provided namespace='java.package' name='org.sat4j.pb.core' version='2.3.5.v20130525'/>
        <provided namespace='java.package' name='org.sat4j.pb.orders' version='2.3.5.v20130525'/>
        <provided namespace='java.package' name='org.sat4j.pb.reader' version='2.3.5.v20130525'/>
        <provided namespace='java.package' name='org.sat4j.pb.tools' version='2.3.5.v20130525'/>
        <provided namespace='osgi.identity' name='org.sat4j.pb' version='2.3.5.v201308161310'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.sat4j.core' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.5))'>
          <description>
            org.sat4j.pb
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.sat4j.pb' version='2.3.5.v201308161310'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.sat4j.pb&#xA;Bundle-Version: 2.3.5.v201308161310
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.tukaani.xz' version='1.11.0' singleton='false'>
      <update id='org.tukaani.xz' range='[0.0.0,1.11.0)' severity='0'/>
      <properties size='2'>
        <property name='org.eclipse.equinox.p2.name' value='XZ data compression'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://tukaani.org/xz/xz-javadoc/'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.tukaani.xz' version='1.11.0'/>
        <provided namespace='osgi.bundle' name='org.tukaani.xz' version='1.11.0'/>
        <provided namespace='java.package' name='org.tukaani.xz' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.tukaani.xz' version='1.11.0'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.tukaani.xz' version='1.11.0'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.tukaani.xz&#xA;Bundle-Version: 1.11
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.wso2.carbon.core.runtime.feature.group' version='4.11.18' singleton='false'>
      <update id='org.wso2.carbon.core.runtime.feature.group' range='[0.0.0,4.11.18)' severity='0'/>
      <properties size='7'>
        <property name='org.eclipse.equinox.p2.name' value='WSO2 Carbon - Carbon Runtime Feature'/>
        <property name='org.eclipse.equinox.p2.description' value='This feature contains the carbon core runtime features'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='false'/>
        <property name='df_LT.license' value='Apache License&#xA;Version 2.0, January 2004&#xA;http://www.apache.org/licenses/&#xA;&#xA;TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION&#xA;&#xA;1. Definitions.&#xA;&#xA;&quot;License&quot; shall mean the terms and conditions for use, reproduction,&#xA;and distribution as defined by Sections 1 through 9 of this document.&#xA;&#xA;&quot;Licensor&quot; shall mean the copyright owner or entity authorized by&#xA;the copyright owner that is granting the License.&#xA;&#xA;&quot;Legal Entity&quot; shall mean the union of the acting entity and all&#xA;other entities that control, are controlled by, or are under common&#xA;control with that entity. For the purposes of this definition,&#xA;&quot;control&quot; means (i) the power, direct or indirect, to cause the&#xA;direction or management of such entity, whether by contract or&#xA;otherwise, or (ii) ownership of fifty percent (50%) or more of the&#xA;outstanding shares, or (iii) beneficial ownership of such entity.&#xA;&#xA;&quot;You&quot; (or &quot;Your&quot;) shall mean an individual or Legal Entity&#xA;exercising permissions granted by this License.&#xA;&#xA;&quot;Source&quot; form shall mean the preferred form for making modifications,&#xA;including but not limited to software source code, documentation&#xA;source, and configuration files.&#xA;&#xA;&quot;Object&quot; form shall mean any form resulting from mechanical&#xA;transformation or translation of a Source form, including but&#xA;not limited to compiled object code, generated documentation,&#xA;and conversions to other media types.&#xA;&#xA;&quot;Work&quot; shall mean the work of authorship, whether in Source or&#xA;Object form, made available under the License, as indicated by a&#xA;copyright notice that is included in or attached to the work&#xA;(an example is provided in the Appendix below).&#xA;&#xA;&quot;Derivative Works&quot; shall mean any work, whether in Source or Object&#xA;form, that is based on (or derived from) the Work and for which the&#xA;editorial revisions, annotations, elaborations, or other modifications&#xA;represent, as a whole, an original work of authorship. For the purposes&#xA;of this License, Derivative Works shall not include works that remain&#xA;separable from, or merely link (or bind by name) to the interfaces of,&#xA;the Work and Derivative Works thereof.&#xA;&#xA;&quot;Contribution&quot; shall mean any work of authorship, including&#xA;the original version of the Work and any modifications or additions&#xA;to that Work or Derivative Works thereof, that is intentionally&#xA;submitted to Licensor for inclusion in the Work by the copyright owner&#xA;or by an individual or Legal Entity authorized to submit on behalf of&#xA;the copyright owner. For the purposes of this definition, &quot;submitted&quot;&#xA;means any form of electronic, verbal, or written communication sent&#xA;to the Licensor or its representatives, including but not limited to&#xA;communication on electronic mailing lists, source code control systems,&#xA;and issue tracking systems that are managed by, or on behalf of, the&#xA;Licensor for the purpose of discussing and improving the Work, but&#xA;excluding communication that is conspicuously marked or otherwise&#xA;designated in writing by the copyright owner as &quot;Not a Contribution.&quot;&#xA;&#xA;&quot;Contributor&quot; shall mean Licensor and any individual or Legal Entity&#xA;on behalf of whom a Contribution has been received by Licensor and&#xA;subsequently incorporated within the Work.&#xA;&#xA;2. Grant of Copyright License. Subject to the terms and conditions of&#xA;this License, each Contributor hereby grants to You a perpetual,&#xA;worldwide, non-exclusive, no-charge, royalty-free, irrevocable&#xA;copyright license to reproduce, prepare Derivative Works of,&#xA;publicly display, publicly perform, sublicense, and distribute the&#xA;Work and such Derivative Works in Source or Object form.&#xA;&#xA;3. Grant of Patent License. Subject to the terms and conditions of&#xA;this License, each Contributor hereby grants to You a perpetual,&#xA;worldwide, non-exclusive, no-charge, royalty-free, irrevocable&#xA;(except as stated in this section) patent license to make, have made,&#xA;use, offer to sell, sell, import, and otherwise transfer the Work,&#xA;where such license applies only to those patent claims licensable&#xA;by such Contributor that are necessarily infringed by their&#xA;Contribution(s) alone or by combination of their Contribution(s)&#xA;with the Work to which such Contribution(s) was submitted. If You&#xA;institute patent litigation against any entity (including a&#xA;cross-claim or counterclaim in a lawsuit) alleging that the Work&#xA;or a Contribution incorporated within the Work constitutes direct&#xA;or contributory patent infringement, then any patent licenses&#xA;granted to You under this License for that Work shall terminate&#xA;as of the date such litigation is filed.&#xA;&#xA;4. Redistribution. You may reproduce and distribute copies of the&#xA;Work or Derivative Works thereof in any medium, with or without&#xA;modifications, and in Source or Object form, provided that You&#xA;meet the following conditions:&#xA;&#xA;(a) You must give any other recipients of the Work or&#xA;Derivative Works a copy of this License; and&#xA;&#xA;(b) You must cause any modified files to carry prominent notices&#xA;stating that You changed the files; and&#xA;&#xA;(c) You must retain, in the Source form of any Derivative Works&#xA;that You distribute, all copyright, patent, trademark, and&#xA;attribution notices from the Source form of the Work,&#xA;excluding those notices that do not pertain to any part of&#xA;the Derivative Works; and&#xA;&#xA;(d) If the Work includes a &quot;NOTICE&quot; text file as part of its&#xA;distribution, then any Derivative Works that You distribute must&#xA;include a readable copy of the attribution notices contained&#xA;within such NOTICE file, excluding those notices that do not&#xA;pertain to any part of the Derivative Works, in at least one&#xA;of the following places: within a NOTICE text file distributed&#xA;as part of the Derivative Works; within the Source form or&#xA;documentation, if provided along with the Derivative Works; or,&#xA;within a display generated by the Derivative Works, if and&#xA;wherever such third-party notices normally appear. The contents&#xA;of the NOTICE file are for informational purposes only and&#xA;do not modify the License. You may add Your own attribution&#xA;notices within Derivative Works that You distribute, alongside&#xA;or as an addendum to the NOTICE text from the Work, provided&#xA;that such additional attribution notices cannot be construed&#xA;as modifying the License.&#xA;&#xA;You may add Your own copyright statement to Your modifications and&#xA;may provide additional or different license terms and conditions&#xA;for use, reproduction, or distribution of Your modifications, or&#xA;for any such Derivative Works as a whole, provided Your use,&#xA;reproduction, and distribution of the Work otherwise complies with&#xA;the conditions stated in this License.&#xA;&#xA;5. Submission of Contributions. Unless You explicitly state otherwise,&#xA;any Contribution intentionally submitted for inclusion in the Work&#xA;by You to the Licensor shall be under the terms and conditions of&#xA;this License, without any additional terms or conditions.&#xA;Notwithstanding the above, nothing herein shall supersede or modify&#xA;the terms of any separate license agreement you may have executed&#xA;with Licensor regarding such Contributions.&#xA;&#xA;6. Trademarks. This License does not grant permission to use the trade&#xA;names, trademarks, service marks, or product names of the Licensor,&#xA;except as required for reasonable and customary use in describing the&#xA;origin of the Work and reproducing the content of the NOTICE file.&#xA;&#xA;7. Disclaimer of Warranty. Unless required by applicable law or&#xA;agreed to in writing, Licensor provides the Work (and each&#xA;Contributor provides its Contributions) on an &quot;AS IS&quot; BASIS,&#xA;WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or&#xA;implied, including, without limitation, any warranties or conditions&#xA;of TITLE, NON-INFRINGEMENT, MERCHANTABILITY, or FITNESS FOR A&#xA;PARTICULAR PURPOSE. You are solely responsible for determining the&#xA;appropriateness of using or redistributing the Work and assume any&#xA;risks associated with Your exercise of permissions under this License.&#xA;&#xA;8. Limitation of Liability. In no event and under no legal theory,&#xA;whether in tort (including negligence), contract, or otherwise,&#xA;unless required by applicable law (such as deliberate and grossly&#xA;negligent acts) or agreed to in writing, shall any Contributor be&#xA;liable to You for damages, including any direct, indirect, special,&#xA;incidental, or consequential damages of any character arising as a&#xA;result of this License or out of the use or inability to use the&#xA;Work (including but not limited to damages for loss of goodwill,&#xA;work stoppage, computer failure or malfunction, or any and all&#xA;other commercial damages or losses), even if such Contributor&#xA;has been advised of the possibility of such damages.&#xA;&#xA;9. Accepting Warranty or Additional Liability. While redistributing&#xA;the Work or Derivative Works thereof, You may choose to offer,&#xA;and charge a fee for, acceptance of support, warranty, indemnity,&#xA;or other liability obligations and/or rights consistent with this&#xA;License. However, in accepting such obligations, You may act only&#xA;on Your own behalf and on Your sole responsibility, not on behalf&#xA;of any other Contributor, and only if You agree to indemnify,&#xA;defend, and hold each Contributor harmless for any liability&#xA;incurred by, or claims asserted against, such Contributor by reason&#xA;of your accepting any such warranty or additional liability.&#xA;&#xA;END OF TERMS AND CONDITIONS'/>
        <property name='df_LT.copyright' value='Copyright 2014-2015 WSO2, Inc. (http://wso2.com)&#xA;&#xA;Licensed under the Apache License, Version 2.0 (the &quot;License&quot;);&#xA;you may not use this file except in compliance with the License.&#xA;You may obtain a copy of the License at&#xA;&#xA;http://www.apache.org/licenses/LICENSE-2.0&#xA;&#xA;Unless required by applicable law or agreed to in writing, software&#xA;distributed under the License is distributed on an &quot;AS IS&quot; BASIS,&#xA;WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.&#xA;See the License for the specific language governing permissions and&#xA;limitations under the License.'/>
        <property name='df_LT.providerName' value='WSO2 Inc.'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.wso2.carbon.core.runtime.feature.group' version='4.11.18'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='71'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi' range='[3.19.0.v20240213-1246,3.19.0.v20240213-1246]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.expressions' range='[3.9.300.v20240207-1044,3.9.300.v20240207-1044]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.core' range='[2.8.0.v20210618-0742,2.8.0.v20210618-0742]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.tukaani.xz' range='[1.11.0,1.11.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.simpleconfigurator' range='[1.5.200.v20240209-1053,1.5.200.v20240209-1053]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.registry' range='[3.12.0.v20240213-1057,3.12.0.v20240213-1057]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.frameworkadmin' range='[2.3.100.v20240201-0843,2.3.100.v20240201-0843]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.jobs' range='[3.15.200.v20231214-1526,3.15.200.v20231214-1526]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.http.service.api' range='[1.2.2.v20231218-2126,1.2.2.v20231218-2126]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.device' range='[1.1.1.202109301733,1.1.1.202109301733]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.compatibility.state' range='[1.0.200.v20160504-1419,1.0.200.v20160504-1419]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.event' range='[1.4.1.202109301733,1.4.1.202109301733]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.felix.gogo.shell' range='[1.1.4,1.1.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.identity' range='[3.10.0.v20230422-0242,3.10.0.v20230422-0242]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.sat4j.core' range='[2.3.5.v201308161310,2.3.5.v201308161310]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.console' range='[1.2.0.v20210315-2042,1.2.0.v20210315-2042]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.useradmin' range='[1.1.1.202109301733,1.1.1.202109301733]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.updatechecker' range='[1.3.0.v20210315-2228,1.3.0.v20210315-2228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.ds' range='[1.6.200.v20200422-1833,1.6.200.v20200422-1833]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.metadata.repository' range='[1.4.0.v20210315-2228,1.4.0.v20210315-2228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.upnp' range='[1.2.1.202109301733,1.2.1.202109301733]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.frameworkadmin.equinox' range='[1.3.100.v20240213-1609,1.3.100.v20240213-1609]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.prefs' range='[1.1.2.202109301733,1.1.2.202109301733]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.felix.scr' range='[2.2.10,2.2.10]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.util.promise' range='[1.3.0.202212101352,1.3.0.202212101352]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher' range='[1.6.700.v20240213-1244,1.6.700.v20240213-1244]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.jarprocessor' range='[1.2.0.v20210507-0825,1.2.0.v20210507-0825]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.extensionlocation' range='[1.4.0.v20210316-1209,1.4.0.v20210316-1209]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.util' range='[1.1.300.v20190714-1852,1.1.300.v20190714-1852]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.simpleconfigurator.manipulator' range='[2.3.100.v20240201-0843,2.3.100.v20240201-0843]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.component' range='[1.5.1.202212101352,1.5.1.202212101352]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.http.whiteboard' range='[1.1.1.202109301733,1.1.1.202109301733]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.app' range='[1.7.0.v20240213-1427,1.7.0.v20240213-1427]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.engine' range='[2.7.0.v20210328-0514,2.7.0.v20210328-0514]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.publisher.eclipse' range='[1.5.0.v20230330-1254,1.5.0.v20230330-1254]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.repository' range='[2.5.0.v20201013-0853,2.5.0.v20201013-0853]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.security' range='[1.4.600.v20250521-0413,1.4.600.v20250521-0413]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.preferences' range='[3.11.0.v20240210-0844,3.11.0.v20240210-0844]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.director' range='[2.5.0.v20210325-0750,2.5.0.v20210325-0750]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.metadata' range='[2.4.0.v20180320-1220,2.4.0.v20180320-1220]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.director.app' range='[1.2.0.v20210315-2042,1.2.0.v20210315-2042]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.repository.tools' range='[2.3.0.v20210325-0750,2.3.0.v20210325-0750]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.sat4j.pb' range='[2.3.5.v201308161310,2.3.5.v201308161310]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.artifact.repository' range='[1.4.0.v20210129-2007,1.4.0.v20210129-2007]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.util.function' range='[1.2.0.202109301733,1.2.0.202109301733]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf' range='[3.11.0.v20230507-1923,3.11.0.v20230507-1923]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.felix.gogo.command' range='[1.1.2,1.1.2]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.provisioning' range='[1.2.0.201505202024,1.2.0.201505202024]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.touchpoint.natives' range='[1.4.0.v20210326-2048,1.4.0.v20210326-2048]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.publisher' range='[1.6.0.v20210322-0909,1.6.0.v20210322-0909]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.concurrent' range='[1.3.0.v20240213-1244,1.3.0.v20240213-1244]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.services' range='[3.12.0.v20231218-2126,3.12.0.v20231218-2126]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.directorywatcher' range='[1.3.0.v20210316-1209,1.3.0.v20210316-1209]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.common' range='[3.19.0.v20240214-0846,3.19.0.v20240214-0846]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.garbagecollector' range='[1.2.0.v20210316-1209,1.2.0.v20210316-1209]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.metatype' range='[1.4.1.202109301733,1.4.1.202109301733]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.wso2.carbon.osgi.security' range='[4.11.18,4.11.18]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.cm' range='[1.6.1.202109301733,1.6.1.202109301733]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.provider.filetransfer' range='[3.3.0.v20230422-0242,3.3.0.v20230422-0242]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.felix.gogo.runtime' range='[1.1.6,1.1.6]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.filetransfer' range='[5.1.103.v20230705-0614,5.1.103.v20230705-0614]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.runtime' range='[3.31.0.v20240215-1631,3.31.0.v20240215-1631]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.transport.ecf' range='[1.2.0.v20180222-0922,1.2.0.v20180222-0922]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.touchpoint.eclipse' range='[2.3.0.v20210315-2228,2.3.0.v20210315-2228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.contenttype' range='[3.9.300.v20231218-0909,3.9.300.v20231218-0909]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.console' range='[1.4.700.v20240213-1244,1.4.700.v20240213-1244]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.wireadmin' range='[1.0.2.202109301733,1.0.2.202109301733]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.permissionadmin' range='[1.2.1.202007221806,1.2.1.202007221806]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.updatesite' range='[1.2.0.v20210322-0909,1.2.0.v20210322-0909]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.provider.filetransfer.httpclient' range='[4.0.200.v20120319-0616,4.0.200.v20120319-0616]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.wso2.carbon.core.runtime.feature.jar' range='[4.11.18,4.11.18]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='org.wso2.carbon.core.runtime.feature.jar' version='4.11.18'>
      <properties size='6'>
        <property name='org.eclipse.equinox.p2.name' value='WSO2 Carbon - Carbon Runtime Feature'/>
        <property name='org.eclipse.equinox.p2.description' value='This feature contains the carbon core runtime features'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='df_LT.license' value='Apache License&#xA;Version 2.0, January 2004&#xA;http://www.apache.org/licenses/&#xA;&#xA;TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION&#xA;&#xA;1. Definitions.&#xA;&#xA;&quot;License&quot; shall mean the terms and conditions for use, reproduction,&#xA;and distribution as defined by Sections 1 through 9 of this document.&#xA;&#xA;&quot;Licensor&quot; shall mean the copyright owner or entity authorized by&#xA;the copyright owner that is granting the License.&#xA;&#xA;&quot;Legal Entity&quot; shall mean the union of the acting entity and all&#xA;other entities that control, are controlled by, or are under common&#xA;control with that entity. For the purposes of this definition,&#xA;&quot;control&quot; means (i) the power, direct or indirect, to cause the&#xA;direction or management of such entity, whether by contract or&#xA;otherwise, or (ii) ownership of fifty percent (50%) or more of the&#xA;outstanding shares, or (iii) beneficial ownership of such entity.&#xA;&#xA;&quot;You&quot; (or &quot;Your&quot;) shall mean an individual or Legal Entity&#xA;exercising permissions granted by this License.&#xA;&#xA;&quot;Source&quot; form shall mean the preferred form for making modifications,&#xA;including but not limited to software source code, documentation&#xA;source, and configuration files.&#xA;&#xA;&quot;Object&quot; form shall mean any form resulting from mechanical&#xA;transformation or translation of a Source form, including but&#xA;not limited to compiled object code, generated documentation,&#xA;and conversions to other media types.&#xA;&#xA;&quot;Work&quot; shall mean the work of authorship, whether in Source or&#xA;Object form, made available under the License, as indicated by a&#xA;copyright notice that is included in or attached to the work&#xA;(an example is provided in the Appendix below).&#xA;&#xA;&quot;Derivative Works&quot; shall mean any work, whether in Source or Object&#xA;form, that is based on (or derived from) the Work and for which the&#xA;editorial revisions, annotations, elaborations, or other modifications&#xA;represent, as a whole, an original work of authorship. For the purposes&#xA;of this License, Derivative Works shall not include works that remain&#xA;separable from, or merely link (or bind by name) to the interfaces of,&#xA;the Work and Derivative Works thereof.&#xA;&#xA;&quot;Contribution&quot; shall mean any work of authorship, including&#xA;the original version of the Work and any modifications or additions&#xA;to that Work or Derivative Works thereof, that is intentionally&#xA;submitted to Licensor for inclusion in the Work by the copyright owner&#xA;or by an individual or Legal Entity authorized to submit on behalf of&#xA;the copyright owner. For the purposes of this definition, &quot;submitted&quot;&#xA;means any form of electronic, verbal, or written communication sent&#xA;to the Licensor or its representatives, including but not limited to&#xA;communication on electronic mailing lists, source code control systems,&#xA;and issue tracking systems that are managed by, or on behalf of, the&#xA;Licensor for the purpose of discussing and improving the Work, but&#xA;excluding communication that is conspicuously marked or otherwise&#xA;designated in writing by the copyright owner as &quot;Not a Contribution.&quot;&#xA;&#xA;&quot;Contributor&quot; shall mean Licensor and any individual or Legal Entity&#xA;on behalf of whom a Contribution has been received by Licensor and&#xA;subsequently incorporated within the Work.&#xA;&#xA;2. Grant of Copyright License. Subject to the terms and conditions of&#xA;this License, each Contributor hereby grants to You a perpetual,&#xA;worldwide, non-exclusive, no-charge, royalty-free, irrevocable&#xA;copyright license to reproduce, prepare Derivative Works of,&#xA;publicly display, publicly perform, sublicense, and distribute the&#xA;Work and such Derivative Works in Source or Object form.&#xA;&#xA;3. Grant of Patent License. Subject to the terms and conditions of&#xA;this License, each Contributor hereby grants to You a perpetual,&#xA;worldwide, non-exclusive, no-charge, royalty-free, irrevocable&#xA;(except as stated in this section) patent license to make, have made,&#xA;use, offer to sell, sell, import, and otherwise transfer the Work,&#xA;where such license applies only to those patent claims licensable&#xA;by such Contributor that are necessarily infringed by their&#xA;Contribution(s) alone or by combination of their Contribution(s)&#xA;with the Work to which such Contribution(s) was submitted. If You&#xA;institute patent litigation against any entity (including a&#xA;cross-claim or counterclaim in a lawsuit) alleging that the Work&#xA;or a Contribution incorporated within the Work constitutes direct&#xA;or contributory patent infringement, then any patent licenses&#xA;granted to You under this License for that Work shall terminate&#xA;as of the date such litigation is filed.&#xA;&#xA;4. Redistribution. You may reproduce and distribute copies of the&#xA;Work or Derivative Works thereof in any medium, with or without&#xA;modifications, and in Source or Object form, provided that You&#xA;meet the following conditions:&#xA;&#xA;(a) You must give any other recipients of the Work or&#xA;Derivative Works a copy of this License; and&#xA;&#xA;(b) You must cause any modified files to carry prominent notices&#xA;stating that You changed the files; and&#xA;&#xA;(c) You must retain, in the Source form of any Derivative Works&#xA;that You distribute, all copyright, patent, trademark, and&#xA;attribution notices from the Source form of the Work,&#xA;excluding those notices that do not pertain to any part of&#xA;the Derivative Works; and&#xA;&#xA;(d) If the Work includes a &quot;NOTICE&quot; text file as part of its&#xA;distribution, then any Derivative Works that You distribute must&#xA;include a readable copy of the attribution notices contained&#xA;within such NOTICE file, excluding those notices that do not&#xA;pertain to any part of the Derivative Works, in at least one&#xA;of the following places: within a NOTICE text file distributed&#xA;as part of the Derivative Works; within the Source form or&#xA;documentation, if provided along with the Derivative Works; or,&#xA;within a display generated by the Derivative Works, if and&#xA;wherever such third-party notices normally appear. The contents&#xA;of the NOTICE file are for informational purposes only and&#xA;do not modify the License. You may add Your own attribution&#xA;notices within Derivative Works that You distribute, alongside&#xA;or as an addendum to the NOTICE text from the Work, provided&#xA;that such additional attribution notices cannot be construed&#xA;as modifying the License.&#xA;&#xA;You may add Your own copyright statement to Your modifications and&#xA;may provide additional or different license terms and conditions&#xA;for use, reproduction, or distribution of Your modifications, or&#xA;for any such Derivative Works as a whole, provided Your use,&#xA;reproduction, and distribution of the Work otherwise complies with&#xA;the conditions stated in this License.&#xA;&#xA;5. Submission of Contributions. Unless You explicitly state otherwise,&#xA;any Contribution intentionally submitted for inclusion in the Work&#xA;by You to the Licensor shall be under the terms and conditions of&#xA;this License, without any additional terms or conditions.&#xA;Notwithstanding the above, nothing herein shall supersede or modify&#xA;the terms of any separate license agreement you may have executed&#xA;with Licensor regarding such Contributions.&#xA;&#xA;6. Trademarks. This License does not grant permission to use the trade&#xA;names, trademarks, service marks, or product names of the Licensor,&#xA;except as required for reasonable and customary use in describing the&#xA;origin of the Work and reproducing the content of the NOTICE file.&#xA;&#xA;7. Disclaimer of Warranty. Unless required by applicable law or&#xA;agreed to in writing, Licensor provides the Work (and each&#xA;Contributor provides its Contributions) on an &quot;AS IS&quot; BASIS,&#xA;WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or&#xA;implied, including, without limitation, any warranties or conditions&#xA;of TITLE, NON-INFRINGEMENT, MERCHANTABILITY, or FITNESS FOR A&#xA;PARTICULAR PURPOSE. You are solely responsible for determining the&#xA;appropriateness of using or redistributing the Work and assume any&#xA;risks associated with Your exercise of permissions under this License.&#xA;&#xA;8. Limitation of Liability. In no event and under no legal theory,&#xA;whether in tort (including negligence), contract, or otherwise,&#xA;unless required by applicable law (such as deliberate and grossly&#xA;negligent acts) or agreed to in writing, shall any Contributor be&#xA;liable to You for damages, including any direct, indirect, special,&#xA;incidental, or consequential damages of any character arising as a&#xA;result of this License or out of the use or inability to use the&#xA;Work (including but not limited to damages for loss of goodwill,&#xA;work stoppage, computer failure or malfunction, or any and all&#xA;other commercial damages or losses), even if such Contributor&#xA;has been advised of the possibility of such damages.&#xA;&#xA;9. Accepting Warranty or Additional Liability. While redistributing&#xA;the Work or Derivative Works thereof, You may choose to offer,&#xA;and charge a fee for, acceptance of support, warranty, indemnity,&#xA;or other liability obligations and/or rights consistent with this&#xA;License. However, in accepting such obligations, You may act only&#xA;on Your own behalf and on Your sole responsibility, not on behalf&#xA;of any other Contributor, and only if You agree to indemnify,&#xA;defend, and hold each Contributor harmless for any liability&#xA;incurred by, or claims asserted against, such Contributor by reason&#xA;of your accepting any such warranty or additional liability.&#xA;&#xA;END OF TERMS AND CONDITIONS'/>
        <property name='df_LT.copyright' value='Copyright 2014-2015 WSO2, Inc. (http://wso2.com)&#xA;&#xA;Licensed under the Apache License, Version 2.0 (the &quot;License&quot;);&#xA;you may not use this file except in compliance with the License.&#xA;You may obtain a copy of the License at&#xA;&#xA;http://www.apache.org/licenses/LICENSE-2.0&#xA;&#xA;Unless required by applicable law or agreed to in writing, software&#xA;distributed under the License is distributed on an &quot;AS IS&quot; BASIS,&#xA;WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.&#xA;See the License for the specific language governing permissions and&#xA;limitations under the License.'/>
        <property name='df_LT.providerName' value='WSO2 Inc.'/>
      </properties>
      <provides size='3'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.wso2.carbon.core.runtime.feature.jar' version='4.11.18'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='feature' version='1.0.0'/>
        <provided namespace='org.eclipse.update.feature' name='org.wso2.carbon.core.runtime' version='4.11.18'/>
      </provides>
      <filter>
        (org.eclipse.update.install.features=true)
      </filter>
      <artifacts size='1'>
        <artifact classifier='org.eclipse.update.feature' id='org.wso2.carbon.core.runtime' version='4.11.18'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='zipped'>
            true
          </instruction>
        </instructions>
      </touchpointData>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='org.wso2.carbon.osgi.security' version='4.11.18' singleton='false' generation='2'>
      <update id='org.wso2.carbon.osgi.security' range='[0.0.0,4.11.18)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='WSO2 Carbon - OSGi Security'/>
        <property name='org.eclipse.equinox.p2.description' value='OSGi Security Bundle. This bundle manages &amp; assigns OSGi permissions to WSO2 Carbon bundles.'/>
        <property name='org.eclipse.equinox.p2.provider' value='WSO2 LLC'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='http://wso2.com'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.wso2.carbon.osgi.security' version='4.11.18'/>
        <provided namespace='osgi.bundle' name='org.wso2.carbon.osgi.security' version='4.11.18'/>
        <provided namespace='java.package' name='org.wso2.carbon.osgi.security' version='4.11.18'/>
        <provided namespace='osgi.identity' name='org.wso2.carbon.osgi.security' version='4.11.18'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='6'>
        <required namespace='java.package' name='java.lang' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.security' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.10.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.service.permissionadmin' range='[1.2.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.wso2.carbon.osgi.security' range='0.0.0' optional='true' greedy='false'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=21))'>
          <description>
            org.wso2.carbon.osgi.security
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.wso2.carbon.osgi.security' version='4.11.18'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.wso2.carbon.osgi.security&#xA;Bundle-Version: 4.11.18
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='tomcat-servlet-api-jdk21' version='9.0.116.wso2v1' singleton='false'>
      <update id='tomcat-servlet-api-jdk21' range='[0.0.0,9.0.116.wso2v1)' severity='0'/>
      <properties size='2'>
        <property name='org.eclipse.equinox.p2.name' value='tomcat-servlet-api-jdk21'/>
        <property name='org.eclipse.equinox.p2.description' value='Apache Tomcat Servlet API'/>
      </properties>
      <provides size='10'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='tomcat-servlet-api-jdk21' version='9.0.116.wso2v1'/>
        <provided namespace='osgi.bundle' name='tomcat-servlet-api-jdk21' version='9.0.116.wso2v1'/>
        <provided namespace='java.package' name='javax.servlet' version='3.1.0'/>
        <provided namespace='java.package' name='javax.servlet.annotation' version='3.1.0'/>
        <provided namespace='java.package' name='javax.servlet.descriptor' version='3.1.0'/>
        <provided namespace='java.package' name='javax.servlet.http' version='3.1.0'/>
        <provided namespace='java.package' name='javax.servlet.resources' version='3.1.0'/>
        <provided namespace='osgi.identity' name='tomcat-servlet-api-jdk21' version='9.0.116.wso2v1'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='osgi.contract' name='JavaServlet' version='3.1.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='tomcat-servlet-api-jdk21' version='9.0.116.wso2v1'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: tomcat-servlet-api-jdk21&#xA;Bundle-Version: 9.0.116.wso2v1
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='tooling.org.eclipse.update.feature.default' version='1.0.0' singleton='false'>
      <hostRequirements size='1'>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='feature' range='0.0.0' optional='true' multiple='true' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='tooling.org.eclipse.update.feature.default' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='tooling' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='feature' range='0.0.0' optional='true' multiple='true' greedy='false'/>
      </requires>
      <filter>
        (org.eclipse.update.install.features=true)
      </filter>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='uninstall'>
            uninstallFeature(feature:${artifact},featureId:default,featureVersion:default)
          </instruction>
          <instruction key='install'>
            installFeature(feature:${artifact},featureId:default,featureVersion:default)
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='tooling.osgi.bundle.default' version='1.0.0' singleton='false'>
      <hostRequirements size='1'>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='0.0.0' multiple='true' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='tooling.osgi.bundle.default' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='tooling' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='0.0.0' multiple='true' greedy='false'/>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact})
          </instruction>
          <instruction key='install'>
            installBundle(bundle:${artifact})
          </instruction>
          <instruction key='configure'>
            setStartLevel(startLevel:4);
          </instruction>
          <instruction key='unconfigure'>

          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='tooling.source.default' version='1.0.0' singleton='false'>
      <hostRequirements size='1'>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='source' range='0.0.0' optional='true' multiple='true' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='tooling.source.default' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='tooling' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='source' range='0.0.0' optional='true' multiple='true' greedy='false'/>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='uninstall'>
            removeSourceBundle(bundle:${artifact})
          </instruction>
          <instruction key='install'>
            addSourceBundle(bundle:${artifact})
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolingcarbon.product.id.config.gtk.linux.x86' version='4.11.18' singleton='false'>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolingcarbon.product.id.config.gtk.linux.x86' version='4.11.18'/>
        <provided namespace='toolingcarbon.product.id' name='carbon.product.id.config' version='4.11.18'/>
      </provides>
      <filter>
        (&amp;(osgi.arch=x86)(osgi.os=linux)(osgi.ws=gtk))
      </filter>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='configure'>
            setProgramProperty(propName:eclipse.product,propValue:carbon.product);setProgramProperty(propName:eclipse.application,propValue:carbon.application);setProgramProperty(propName:org.eclipse.equinox.simpleconfigurator.useReference,propValue:true);
          </instruction>
          <instruction key='unconfigure'>
            setProgramProperty(propName:eclipse.product,propValue:);setProgramProperty(propName:eclipse.application,propValue:);setProgramProperty(propName:org.eclipse.equinox.simpleconfigurator.useReference,propValue:);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolingcarbon.product.id.configuration' version='4.11.18'>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolingcarbon.product.id.configuration' version='4.11.18'/>
      </provides>
      <requires size='5'>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.x86org.eclipse.equinox.simpleconfigurator' range='[4.11.18,4.11.18]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.x86org.eclipse.equinox.ds' range='[4.11.18,4.11.18]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.x86org.eclipse.core.runtime' range='[4.11.18,4.11.18]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.x86org.eclipse.equinox.common' range='[4.11.18,4.11.18]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingcarbon.product.id.config.gtk.linux.x86' range='[4.11.18,4.11.18]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
    </unit>
    <unit id='toolinggtk.linux.x86org.eclipse.core.runtime' version='4.11.18' singleton='false'>
      <hostRequirements size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.x86org.eclipse.core.runtime' version='4.11.18'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='toolinggtk.linux.x86' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86)(osgi.os=linux)(osgi.ws=gtk))
      </filter>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact})
          </instruction>
          <instruction key='install'>
            installBundle(bundle:${artifact})
          </instruction>
          <instruction key='configure'>
            setStartLevel(startLevel:4);markStarted(started: true);
          </instruction>
          <instruction key='unconfigure'>
            setStartLevel(startLevel:-1);markStarted(started: false);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolinggtk.linux.x86org.eclipse.equinox.common' version='4.11.18' singleton='false'>
      <hostRequirements size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.x86org.eclipse.equinox.common' version='4.11.18'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='toolinggtk.linux.x86' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86)(osgi.os=linux)(osgi.ws=gtk))
      </filter>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact})
          </instruction>
          <instruction key='install'>
            installBundle(bundle:${artifact})
          </instruction>
          <instruction key='configure'>
            setStartLevel(startLevel:2);markStarted(started: true);
          </instruction>
          <instruction key='unconfigure'>
            setStartLevel(startLevel:-1);markStarted(started: false);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolinggtk.linux.x86org.eclipse.equinox.ds' version='4.11.18' singleton='false'>
      <hostRequirements size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.ds' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.x86org.eclipse.equinox.ds' version='4.11.18'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='toolinggtk.linux.x86' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.ds' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86)(osgi.os=linux)(osgi.ws=gtk))
      </filter>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact})
          </instruction>
          <instruction key='install'>
            installBundle(bundle:${artifact})
          </instruction>
          <instruction key='configure'>
            setStartLevel(startLevel:2);markStarted(started: true);
          </instruction>
          <instruction key='unconfigure'>
            setStartLevel(startLevel:-1);markStarted(started: false);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolinggtk.linux.x86org.eclipse.equinox.simpleconfigurator' version='4.11.18' singleton='false'>
      <hostRequirements size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.simpleconfigurator' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.x86org.eclipse.equinox.simpleconfigurator' version='4.11.18'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='toolinggtk.linux.x86' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.simpleconfigurator' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86)(osgi.os=linux)(osgi.ws=gtk))
      </filter>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact})
          </instruction>
          <instruction key='install'>
            installBundle(bundle:${artifact})
          </instruction>
          <instruction key='configure'>
            setStartLevel(startLevel:1);markStarted(started: true);
          </instruction>
          <instruction key='unconfigure'>
            setStartLevel(startLevel:-1);markStarted(started: false);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
  </units>
  <iusProperties size='86'>
    <iuProperties id='carbon.product.id' version='4.11.18'>
      <properties size='2'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
      </properties>
    </iuProperties>
  </iusProperties>
</profile>
